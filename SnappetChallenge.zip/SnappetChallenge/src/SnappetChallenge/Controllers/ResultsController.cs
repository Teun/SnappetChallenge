﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SnappetChallenge.Data.DomainEntities;
using SnappetChallenge.Data.Repositories;
using SnappetChallenge.Models;
using SnappetChallenge.ServiceLayer;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace SnappetChallenge.Controllers
{
    public class ResultsController : Controller
    {
        private IDailyResultsService _service;

        public ResultsController(IDailyResultsService dailyResultService)
        {
            _service = dailyResultService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult WrongAnswers()
        {
            return View();
        }

        public IActionResult GetResultsForDate()
        {
            return View("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult GetResultsForDate(DateTime submitDate)
        {
            var workedOnModel = _service.GroupWorkBySubjectDomainLO(submitDate);
            var model = new AnswerOverviewModel()
            {
                SelectedDate = submitDate,
                WorkedOn = workedOnModel
            };
            return View("AnswersOverview", model);
        }

        public IActionResult WorkedOnByWeek()
        {
            var model = new List<WorkedOnByWeekModel>();
            var data = _service.GetAll();
            var grouped = data.GroupBy(w => CultureInfo.CurrentCulture.Calendar.GetWeekOfYear(
                             w.SubmitDateTime,
                             CalendarWeekRule.FirstFourDayWeek,
                             DayOfWeek.Sunday))
                             .OrderByDescending(g => g.Key);
            foreach (var group in grouped)
            {
                var weekInformation = new WorkedOnByWeekModel();
                weekInformation.Week = group.Key;
                weekInformation.AnswerCountPerSubject = group.GroupBy(w => w.Subject).ToDictionary(g => g.Key, g => g.Count());
                model.Add(weekInformation);
            }
            return View(model);
        }
    }
}
