﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SnappetChallenge.Models
{
    public class WorkedOnByWeekModel
    {
        public int Week { get; set; }
        public Dictionary<string /*subject*/, int /* answer count*/> AnswerCountPerSubject { get; set; }
    }
}
