﻿In the work.json file I changed 
	- "Difficulty":"NULL",
to
	-"Difficulty":null,
as that is the correct way to specify a null value for float (if the Difficulty field is a float which I assume).