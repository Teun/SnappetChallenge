﻿using SnappetChallenge.Data.DomainEntities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SnappetChallenge.Data.Repositories
{
    public class WorkRepository : IWorkRepository
    {
        private const string SourceFilePath = @"~\..\..\SnappetChallenge.DataLayer\Files\work.json";
        private DateTime Now = new DateTime(2015, 03, 24, 11, 30, 0, DateTimeKind.Utc); // As specified in the ReadMe it is now 24-03-2015 11:30 UTC
        

        public IEnumerable<Work> GetAll()
        {
            return LoadJson();
        }

        public IEnumerable<Work> GetForSubmitDate(DateTime submitDate)
        {
            return GetAll().Where(w => w.SubmitDateTime.Date == submitDate);
        }

        private IEnumerable<Work> LoadJson()
        {
            using (StreamReader file = File.OpenText(SourceFilePath))
            {
                string json = file.ReadToEnd();
                var items = JsonConvert.DeserializeObject<List<Work>>(json);
                return items.Where(w => w.SubmitDateTime <= Now);
            }
        }
    }
}
