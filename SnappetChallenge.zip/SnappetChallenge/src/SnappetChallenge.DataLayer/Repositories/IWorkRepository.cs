﻿using SnappetChallenge.Data.DomainEntities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SnappetChallenge.Data.Repositories
{
    public interface IWorkRepository
    {
        IEnumerable<Work> GetAll();
        IEnumerable<Work> GetForSubmitDate(DateTime submitDate);
    }
}
