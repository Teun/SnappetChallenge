﻿using SnappetChallenge.Data.DomainEntities;
using SnappetChallenge.Data.Repositories;
using SnappetChallenge.ServiceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SnappetChallenge.ServiceLayer
{
    public class DailyResultsService : IDailyResultsService
    {
        private IWorkRepository _repository;

        public DailyResultsService(IWorkRepository repository)
        {
            _repository = repository;
        }
        
        public IEnumerable<Work> GetAll()
        {
            return _repository.GetAll();
        }

        public WorkedOnModel GroupWorkBySubjecct(DateTime submitDate)
        {
            var work = _repository.GetForSubmitDate(submitDate);
            var groupingsInOrder = new List<Func<Work, string>> { Subject };
            return CreateWorkedOnModel(work, groupingsInOrder);
        }

        public WorkedOnModel GroupWorkBySubjectDomain(DateTime submitDate)
        {
            var work = _repository.GetForSubmitDate(submitDate);
            var groupingsInOrder = new List<Func<Work, string>> { Subject, Domain };
            return CreateWorkedOnModel(work, groupingsInOrder);
        }

        public WorkedOnModel GroupWorkBySubjectDomainLO(DateTime submitDate)
        {
            var work = _repository.GetForSubmitDate(submitDate);
            var groupingsInOrder = new List<Func<Work, string>> { Subject, Domain, LearningObjective };
            return CreateWorkedOnModel(work, groupingsInOrder);
        }

        private WorkedOnModel CreateWorkedOnModel(IEnumerable<Work> work, List<Func<Work, string>> groupingsInOrder)
        {
            var root = CreateWorkedOnModel("Totaal aantal ontvangen antwoorden", work);
            GroupAndCreateWorkedOnModel(root, work, groupingsInOrder);

            return root;
        }

        private void GroupAndCreateWorkedOnModel(WorkedOnModel parent, IEnumerable<Work> work, IEnumerable<Func<Work, string>> groupingsInOrder)
        {
            // If no groupings are left return
            if (!groupingsInOrder.Any())
                return;

            var func = groupingsInOrder.First();
            var groupedWork = work.GroupBy(func).OrderBy(g => g.Key); // Group by specific property e.g. Subject
            foreach (var subGrouping in groupedWork)
            {
                // Create a workedOnModel for each subGroup
                var subjectModel = CreateWorkedOnModel(subGrouping.Key, subGrouping);
                // Add to parent item to create hierarchy
                parent.Items.Add(subjectModel);
                // Group each subGroup based on the groupingOrder
                GroupAndCreateWorkedOnModel(subjectModel, subGrouping.Select(w => w), groupingsInOrder.Skip(1));
            }
        }

        private WorkedOnModel CreateWorkedOnModel(string groupName, IEnumerable<Work> work)
        {
            return new WorkedOnModel
            {
                Name = groupName,
                TotalAnswersCount = work.Count(),
                WrongAnswersCount = work.Count(w => !w.Correct),
                CorrectAnswersCount = work.Count(w => w.Correct)
            };
        }

        #region Grouping Functions
        private string Subject(Work model)
        {
            return model.Subject;
        }

        private string Domain(Work model)
        {
            return model.Domain;
        }

        private string LearningObjective(Work model)
        {
            return model.LearningObjective;
        }
        #endregion Grouping Functions

    }
}
