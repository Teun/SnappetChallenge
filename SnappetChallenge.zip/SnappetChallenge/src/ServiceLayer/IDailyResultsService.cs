﻿using SnappetChallenge.Data.DomainEntities;
using SnappetChallenge.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SnappetChallenge.ServiceLayer
{
    public interface IDailyResultsService
    {
        IEnumerable<Work> GetAll();

        WorkedOnModel GroupWorkBySubjecct(DateTime submitDate);
        WorkedOnModel GroupWorkBySubjectDomain(DateTime submitDate);
        WorkedOnModel GroupWorkBySubjectDomainLO(DateTime submitDate);
    }
}
