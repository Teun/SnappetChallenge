﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SnappetChallenge.ServiceLayer
{
    public class WorkedOnModel
    {
        public string Name { get; set; }
        public int TotalAnswersCount { get; set; }
        public int WrongAnswersCount { get; set; }
        public int CorrectAnswersCount { get; set; }
        public List<WorkedOnModel> Items { get; set;}

        public WorkedOnModel()
        {
            Items = new List<WorkedOnModel>();
        }        
    }
}
