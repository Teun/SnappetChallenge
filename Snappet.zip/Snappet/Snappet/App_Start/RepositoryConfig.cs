﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Hosting;
using Newtonsoft.Json;
using Snappet.Helper;
using Snappet.Mapping;

namespace Snappet.App_Start
{
    public class RepositoryConfig
    {
        public static void RegisterRepository()
        {
            try{
                var sr = new StreamReader(HostingEnvironment.MapPath(@"~/App_Data/work.json"));
                string jsonString = sr.ReadToEnd();

                var deser =
                    (List<ChildData>)
                        JsonConvert.DeserializeObject(jsonString, typeof (List<ChildData>),
                            new JsonManager.FormatConverter());
                var myData =
                    deser.Where(a => a.InProgress != 0 && a.CreateDate <= Convert.ToDateTime("2015-03-25")).ToList();

                var dataManager = new RepositoryManger();
                dataManager.SetData(myData);
            }
            catch (Exception ex){
                MvcApplication.Logger.Error(ex);
            }
        }
    }
}