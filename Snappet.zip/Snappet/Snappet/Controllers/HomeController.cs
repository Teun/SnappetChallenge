﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using Snappet.Entities;
using Snappet.Helper;
using Snappet.Mapping;

namespace Snappet.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class HomeController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult Rapport(string type)
        {
            try{
                BaseRapport output;
                using (var repository = new RepositoryManger()){
                    var baseData = repository.GetData().ToList();
                    var subject = GetBaseRapport(baseData, type);

                    var rapport = new RapportFactory<ChildData>();
                    output =
                        rapport.CreateRapport(
                            subject.Select(a => a.Key.ToString(CultureInfo.InvariantCulture)).ToArray(), baseData,
                            GetPropertyByRapport(type));
                }

                if (Request.IsAjaxRequest()){
                    return new JsonResult {Data = output, JsonRequestBehavior = JsonRequestBehavior.AllowGet};
                }
                return new JsonResult {Data = string.Empty, JsonRequestBehavior = JsonRequestBehavior.AllowGet};
            }
            catch (Exception ex){
                MvcApplication.Logger.Error(ex);
                return new JsonResult {Data = "error", JsonRequestBehavior = JsonRequestBehavior.AllowGet};
            }
        }

        private IEnumerable<IGrouping<string, ChildData>> GetBaseRapport(IEnumerable<ChildData> data, string type)
        {
            switch (type){
                case "ByUser":
                    return data.GroupBy(pet => pet.UserId.ToString(CultureInfo.InvariantCulture)).ToList();
                case "ByProgress":
                    return data.GroupBy(pet => pet.InProgress.ToString(CultureInfo.InvariantCulture)).ToList();
                case "ByDate":
                    return data.GroupBy(pet => pet.CreateDate.ToShortDateString()).ToList();
                case "BySubject":
                    return data.GroupBy(pet => pet.Subject).ToList();
                case "ByDomain":
                    return data.GroupBy(pet => pet.Domain).ToList();
            }
            return null;
        }

        private string GetPropertyByRapport(string type)
        {
            switch (type){
                case "ByUser":
                    return "UserId";
                case "ByProgress":
                    return "InProgress";
                case "ByDate":
                    return "CreateDate";
                case "BySubject":
                    return "Subject";
                case "ByDomain":
                    return "Domain";
            }
            return null;
        }
    }
}