﻿using System;
using Newtonsoft.Json;

namespace Snappet.Helper
{
    /// <summary>
    /// 
    /// </summary>
    public class JsonManager
    {
        /// <summary>
        /// 
        /// </summary>
        public class FormatConverter : JsonConverter
        {
            /// <summary>
            /// 
            /// </summary>
            /// <param name="writer"></param>
            /// <param name="value"></param>
            /// <param name="serializer"></param>
            public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
            {
                throw new NotImplementedException();
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="reader"></param>
            /// <param name="objectType"></param>
            /// <param name="existingValue"></param>
            /// <param name="serializer"></param>
            /// <returns></returns>
            public override object ReadJson(JsonReader reader, Type objectType, object existingValue,
                JsonSerializer serializer)
            {
                if (objectType == typeof (double)){
                    if (reader.Value.ToString().ToLower() == "null"){
                        return Convert.ToDouble(0);
                    }
                    return Convert.ToDouble(reader.Value.ToString());
                }

                return reader.Value;
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="objectType"></param>
            /// <returns></returns>
            public override bool CanConvert(Type objectType)
            {
                return objectType == typeof (double);
            }
        }
    }
}