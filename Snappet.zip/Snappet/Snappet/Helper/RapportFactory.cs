﻿using System;
using System.Collections.Generic;
using System.Linq;
using Snappet.Entities;

namespace Snappet.Helper
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class RapportFactory<T>
    {
        public class Demension
        {
            public string Name { get; set; }
            public string Value { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        private sealed class Layer
        {
            public string X { get; set; }
            public int Y { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private IEnumerable<Layer> ConvertToRepository(IEnumerable<string> data)
        {
            return data.Select(item => new Layer
            {
                X = item,
                Y = 0
            }).ToList();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="layout"></param>
        /// <param name="data"></param>
        /// <param name="property"></param>
        /// <returns></returns>
        public BaseRapport CreateRapport(IEnumerable<string> layout, List<T> data, string property)
        {
            var rapportLayer = ConvertToRepository(layout);
            var b = (from item in rapportLayer
                let dimension = new List<Demension>
                {
                    new Demension
                    {
                        Name = property,
                        Value = item.X
                    }
                }
                let items = Filter(data, dimension)
                select new Layer
                {
                    X = item.X,
                    Y = items
                }).ToList();
            return new BaseRapport {X = b.Select(a => a.X).ToArray(), Y = b.Select(a => a.Y).ToArray()};
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="collection"></param>
        /// <param name="dimension"></param>
        /// <returns></returns>
        private static int Filter(IEnumerable<T> collection, IEnumerable<Demension> dimension)
        {
            var count = 0;

            foreach (var item in collection){
                foreach (var myDimension in dimension){
                    var type = item.GetType();
                    var dataProperty = type.GetProperty(myDimension.Name);
                    if (dataProperty == null) continue;
                    var data = dataProperty.GetValue(item).ToString();

                    if (dataProperty.PropertyType == typeof (DateTime)){
                        var date = Convert.ToDateTime(data);
                        if (date.ToShortDateString() == myDimension.Value){
                            count++;
                        }
                    }
                    else if (dataProperty.PropertyType == typeof (string)){
                        if (data == myDimension.Value){
                            count++;
                        }
                    }
                    else if (dataProperty.PropertyType == typeof (int)){
                        if (Convert.ToInt32(data) == Convert.ToInt32(myDimension.Value)){
                            count++;
                        }
                    }
                }
            }
            return count;
        }
    }
}