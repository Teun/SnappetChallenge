﻿using System;
using System.Runtime.Caching;

namespace Snappet.Helper
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomCacheProvider : ICacheProvider
    {
        #region Fields

        private MemoryCache _memoryCache;

        #endregion

        #region Properties

        /// <summary>
        /// 
        /// </summary>
        private ObjectCache Cache
        {
            get { return _memoryCache ?? (_memoryCache = MemoryCache.Default); }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public object Get(string key)
        {
            return Cache[key];
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="cacheTime"></param>
        public void Set(string key, object data, int cacheTime)
        {
            if (Cache.Contains(key)) Cache.Remove(key);
            var policy = new CacheItemPolicy {AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(cacheTime)};
            Cache.Add(new CacheItem(key, data), policy);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool IsSet(string key)
        {
            return (Cache[key] != null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        public void Invalidate(string key)
        {
            Cache.Remove(key);
        }

        #endregion
    }
}