﻿using System;
using System.Collections.Generic;
using Snappet.Mapping;

namespace Snappet.Helper
{
    /// <summary>
    /// 
    /// </summary>
    public class RepositoryManger : IDisposable
    {
        #region Properties

        private ICacheProvider Cache { get; set; }

        #endregion

        #region Constructor

        /// <summary>
        /// 
        /// </summary>
        public RepositoryManger()
            : this(new CustomCacheProvider())
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customCacheProvider"></param>
        private RepositoryManger(ICacheProvider customCacheProvider)
        {
            Cache = customCacheProvider;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="myData"></param>
        public void SetData(List<ChildData> myData)
        {
            Cache.Set("ChildData", myData, 60);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ChildData> GetData()
        {
            return (List<ChildData>) Cache.Get("ChildData");
        }

        #endregion

        public void Dispose()
        {
        }
    }
}