﻿using System;
using Newtonsoft.Json;

namespace Snappet.Mapping
{
    /// <summary>
    /// 
    /// </summary>
    public class ChildData
    {
        /// <summary>
        /// SubmittedAnswerId:2395278
        /// </summary>
        [JsonProperty(PropertyName = "SubmittedAnswerId")]
        public int AnswerId { get; set; }

        /// <summary>
        /// SubmitDateTime:2015-03-02T07:35:38.740
        /// </summary>
        [JsonProperty(PropertyName = "SubmitDateTime")]
        public DateTime CreateDate { get; set; }

        /// <summary>
        /// Correct":1
        /// </summary>
        [JsonProperty(PropertyName = "Correct")]
        public int Answard { get; set; }

        //"Progress":0,
        [JsonProperty(PropertyName = "Progress")]
        public int InProgress { get; set; }

        /// <summary>
        /// UserId:40281
        /// </summary>
        [JsonProperty(PropertyName = "UserId")]
        public int UserId { get; set; }

        /// <summary>
        /// ExerciseId:1029121
        /// </summary>
        [JsonProperty(PropertyName = "ExerciseId")]
        public int Exercise { get; set; }

        /// <summary>
        /// Difficulty: -200
        /// </summary>
        [JsonProperty(PropertyName = "Difficulty")]
        public double Complex { get; set; }

        /// <summary>
        /// Subject:Begrijpend Lezen
        /// </summary>
        [JsonProperty(PropertyName = "Subject")]
        public string Subject { get; set; }

        /// <summary>
        /// LearningObjective:"Diverse leerdoelen Begrijpend Lezen
        /// </summary>
        [JsonProperty(PropertyName = "LearningObjective")]
        public string SubSubject { get; set; }

        /// <summary>
        /// Domain
        /// </summary>
        [JsonProperty(PropertyName = "Domain")]
        public string Domain { get; set; }
    }
}