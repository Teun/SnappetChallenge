/*!
 * Knockout JavaScript library v3.3.0
 * (c) Steven Sanderson - http://knockoutjs.com/
 * License: MIT (http://www.opensource.org/licenses/mit-license.php)
 */

(function() {
    (function(p) {
        var y = this || (0, eval)("this"), w = y.document, M = y.navigator, u = y.jQuery, E = y.JSON;
        (function(p) { "function" === typeof define && define.amd ? define(["exports", "require"], p) : "function" === typeof require && "object" === typeof exports && "object" === typeof module ? p(module.exports || exports) : p(y.ko = {}) })(function(N, O) {
            function J(a, d) { return null === a || typeof a in Q ? a === d : !1 }

            function R(a, d) {
                var c;
                return function() {
                    c || (c = setTimeout(function() {
                        c = p;
                        a()
                    }, d))
                }
            }

            function S(a, d) {
                var c;
                return function() {
                    clearTimeout(c);
                    c = setTimeout(a, d)
                }
            }

            function K(b, d, c, e) {
                a.d[b] = {
                    init: function(b, k, h, l, g) {
                        var m, x;
                        a.w(function() {
                            var q = a.a.c(k()), n = !c !== !q, r = !x;
                            if (r || d || n !== m)r && a.Z.oa() && (x = a.a.la(a.e.childNodes(b), !0)), n ? (r || a.e.T(b, a.a.la(x)), a.Ja(e ? e(g, q) : g, b)) : a.e.ma(b), m = n
                        }, null, { q: b });
                        return{ controlsDescendantBindings: !0 }
                    }
                };
                a.h.ka[b] = !1;
                a.e.R[b] = !0
            }

            var a = "undefined" !== typeof N ? N : {};
            a.b = function(b, d) {
                for (var c = b.split("."), e = a, f = 0; f < c.length - 1; f++)e = e[c[f]];
                e[c[c.length - 1]] = d
            };
            a.D = function(a, d, c) { a[d] = c };
            a.version = "3.3.0";
            a.b("version", a.version);
            a.a = function() {
                function b(a, b) { for (var c in a)a.hasOwnProperty(c) && b(c, a[c]) }

                function d(a, b) {
                    if (b)for (var c in b)b.hasOwnProperty(c) && (a[c] = b[c]);
                    return a
                }

                function c(a, b) {
                    a.__proto__ = b;
                    return a
                }

                function e(b, c, g, d) {
                    var e = b[c].match(m) || [];
                    a.a.o(g.match(m), function(b) { a.a.ga(e, b, d) });
                    b[c] = e.join(" ")
                }

                var f = { __proto__: [] } instanceof Array, k = {}, h = {};
                k[M && /Firefox\/2/i.test(M.userAgent) ? "KeyboardEvent" : "UIEvents"] = ["keyup", "keydown", "keypress"];
                k.MouseEvents = "click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave".split(" ");
                b(k, function(a, b) { if (b.length)for (var c = 0, g = b.length; c < g; c++)h[b[c]] = a });
                var l = { propertychange: !0 },
                    g = w && function() {
                        for (var a = 3, b = w.createElement("div"), c = b.getElementsByTagName("i"); b.innerHTML = "\x3c!--[if gt IE " + ++a + "]><i></i><![endif]--\x3e", c[0];);
                        return 4 < a ? a : p
                    }(),
                    m = /\S+/g;
                return{
                    Bb: ["authenticity_token", /^__RequestVerificationToken(_.*)?$/],
                    o: function(a, b) { for (var c = 0, g = a.length; c < g; c++)b(a[c], c) },
                    m: function(a, b) {
                        if ("function" == typeof Array.prototype.indexOf)
                            return Array.prototype.indexOf.call(a,
                                b);
                        for (var c = 0, g = a.length; c < g; c++)if (a[c] === b)return c;
                        return-1
                    },
                    vb: function(a, b, c) {
                        for (var g = 0, d = a.length; g < d; g++)if (b.call(c, a[g], g))return a[g];
                        return null
                    },
                    ya: function(b, c) {
                        var g = a.a.m(b, c);
                        0 < g ? b.splice(g, 1) : 0 === g && b.shift()
                    },
                    wb: function(b) {
                        b = b || [];
                        for (var c = [], g = 0, d = b.length; g < d; g++)0 > a.a.m(c, b[g]) && c.push(b[g]);
                        return c
                    },
                    Ka: function(a, b) {
                        a = a || [];
                        for (var c = [], g = 0, d = a.length; g < d; g++)c.push(b(a[g], g));
                        return c
                    },
                    xa: function(a, b) {
                        a = a || [];
                        for (var c = [], g = 0, d = a.length; g < d; g++)b(a[g], g) && c.push(a[g]);
                        return c
                    },
                    ia: function(a, b) {
                        if (b instanceof Array)a.push.apply(a, b);
                        else for (var c = 0, g = b.length; c < g; c++)a.push(b[c]);
                        return a
                    },
                    ga: function(b, c, g) {
                        var d = a.a.m(a.a.cb(b), c);
                        0 > d ? g && b.push(c) : g || b.splice(d, 1)
                    },
                    za: f,
                    extend: d,
                    Fa: c,
                    Ga: f ? c : d,
                    A: b,
                    pa: function(a, b) {
                        if (!a)return a;
                        var c = {}, g;
                        for (g in a)a.hasOwnProperty(g) && (c[g] = b(a[g], g, a));
                        return c
                    },
                    Ra: function(b) { for (; b.firstChild;)a.removeNode(b.firstChild) },
                    Jb: function(b) {
                        b = a.a.O(b);
                        for (var c = (b[0] && b[0].ownerDocument || w).createElement("div"), g = 0, d = b.length; g <
                            d; g++)c.appendChild(a.S(b[g]));
                        return c
                    },
                    la: function(b, c) {
                        for (var g = 0, d = b.length, e = []; g < d; g++) {
                            var m = b[g].cloneNode(!0);
                            e.push(c ? a.S(m) : m)
                        }
                        return e
                    },
                    T: function(b, c) {
                        a.a.Ra(b);
                        if (c)for (var g = 0, d = c.length; g < d; g++)b.appendChild(c[g])
                    },
                    Qb: function(b, c) {
                        var g = b.nodeType ? [b] : b;
                        if (0 < g.length) {
                            for (var d = g[0], e = d.parentNode, m = 0, f = c.length; m < f; m++)e.insertBefore(c[m], d);
                            m = 0;
                            for (f = g.length; m < f; m++)a.removeNode(g[m])
                        }
                    },
                    na: function(a, b) {
                        if (a.length) {
                            for (b = 8 === b.nodeType && b.parentNode || b; a.length && a[0].parentNode !==
                                b;)a.splice(0, 1);
                            if (1 < a.length) {
                                var c = a[0], g = a[a.length - 1];
                                for (a.length = 0; c !== g;)if (a.push(c), c = c.nextSibling, !c)return;
                                a.push(g)
                            }
                        }
                        return a
                    },
                    Sb: function(a, b) { 7 > g ? a.setAttribute("selected", b) : a.selected = b },
                    ib: function(a) { return null === a || a === p ? "" : a.trim ? a.trim() : a.toString().replace(/^[\s\xa0]+|[\s\xa0]+$/g, "") },
                    Dc: function(a, b) {
                        a = a || "";
                        return b.length > a.length ? !1 : a.substring(0, b.length) === b
                    },
                    jc: function(a, b) {
                        if (a === b)return!0;
                        if (11 === a.nodeType)return!1;
                        if (b.contains)
                            return b.contains(3 === a.nodeType ?
                                a.parentNode : a);
                        if (b.compareDocumentPosition)return 16 == (b.compareDocumentPosition(a) & 16);
                        for (; a && a != b;)a = a.parentNode;
                        return!!a
                    },
                    Qa: function(b) { return a.a.jc(b, b.ownerDocument.documentElement) },
                    tb: function(b) { return!!a.a.vb(b, a.a.Qa) },
                    v: function(a) { return a && a.tagName && a.tagName.toLowerCase() },
                    n: function(b, c, d) {
                        var m = g && l[c];
                        if (!m && u)u(b).bind(c, d);
                        else if (m || "function" != typeof b.addEventListener)
                            if ("undefined" != typeof b.attachEvent) {
                                var e = function(a) { d.call(b, a) }, f = "on" + c;
                                b.attachEvent(f, e);
                                a.a.C.fa(b,
                                    function() { b.detachEvent(f, e) })
                            } else throw Error("Browser doesn't support addEventListener or attachEvent");
                        else b.addEventListener(c, d, !1)
                    },
                    qa: function(b, c) {
                        if (!b || !b.nodeType)throw Error("element must be a DOM node when calling triggerEvent");
                        var g;
                        "input" === a.a.v(b) && b.type && "click" == c.toLowerCase() ? (g = b.type, g = "checkbox" == g || "radio" == g) : g = !1;
                        if (u && !g)u(b).trigger(c);
                        else if ("function" == typeof w.createEvent)
                            if ("function" == typeof b.dispatchEvent)
                                g = w.createEvent(h[c] || "HTMLEvents"), g.initEvent(c,
                                    !0, !0, y, 0, 0, 0, 0, 0, !1, !1, !1, !1, 0, b), b.dispatchEvent(g);
                            else throw Error("The supplied element doesn't support dispatchEvent");
                        else if (g && b.click)b.click();
                        else if ("undefined" != typeof b.fireEvent)b.fireEvent("on" + c);
                        else throw Error("Browser doesn't support triggering events");
                    },
                    c: function(b) { return a.F(b) ? b() : b },
                    cb: function(b) { return a.F(b) ? b.B() : b },
                    Ia: function(b, c, g) {
                        var d;
                        c && ("object" === typeof b.classList ? (d = b.classList[g ? "add" : "remove"], a.a.o(c.match(m), function(a) { d.call(b.classList, a) })) : "string" ===
                            typeof b.className.baseVal ? e(b.className, "baseVal", c, g) : e(b, "className", c, g))
                    },
                    Ha: function(b, c) {
                        var g = a.a.c(c);
                        if (null === g || g === p)g = "";
                        var d = a.e.firstChild(b);
                        !d || 3 != d.nodeType || a.e.nextSibling(d) ? a.e.T(b, [b.ownerDocument.createTextNode(g)]) : d.data = g;
                        a.a.mc(b)
                    },
                    Rb: function(a, b) {
                        a.name = b;
                        if (7 >= g)
                            try {
                                a.mergeAttributes(w.createElement("<input name='" + a.name + "'/>"), !1)
                            } catch (c) {
                            }
                    },
                    mc: function(a) { 9 <= g && (a = 1 == a.nodeType ? a : a.parentNode, a.style && (a.style.zoom = a.style.zoom)) },
                    kc: function(a) {
                        if (g) {
                            var b = a.style.width;
                            a.style.width = 0;
                            a.style.width = b
                        }
                    },
                    Bc: function(b, c) {
                        b = a.a.c(b);
                        c = a.a.c(c);
                        for (var g = [], d = b; d <= c; d++)g.push(d);
                        return g
                    },
                    O: function(a) {
                        for (var b = [], c = 0, g = a.length; c < g; c++)b.push(a[c]);
                        return b
                    },
                    Hc: 6 === g,
                    Ic: 7 === g,
                    M: g,
                    Db: function(b, c) {
                        for (var g = a.a.O(b.getElementsByTagName("input")).concat(a.a.O(b.getElementsByTagName("textarea"))), d = "string" == typeof c ? function(a) { return a.name === c } : function(a) { return c.test(a.name) }, m = [], e = g.length - 1; 0 <= e; e--)d(g[e]) && m.push(g[e]);
                        return m
                    },
                    yc: function(b) {
                        return"string" ==
                            typeof b && (b = a.a.ib(b)) ? E && E.parse ? E.parse(b) : (new Function("return " + b))() : null
                    },
                    jb: function(b, c, g) {
                        if (!E || !E.stringify)throw Error("Cannot find JSON.stringify(). Some browsers (e.g., IE < 8) don't support it natively, but you can overcome this by adding a script reference to json2.js, downloadable from http://www.json.org/json2.js");
                        return E.stringify(a.a.c(b), c, g)
                    },
                    zc: function(c, g, d) {
                        d = d || {};
                        var m = d.params || {}, e = d.includeFields || this.Bb, f = c;
                        if ("object" == typeof c && "form" === a.a.v(c))
                            for (var f = c.action,
                                l = e.length - 1; 0 <= l; l--)for (var k = a.a.Db(c, e[l]), h = k.length - 1; 0 <= h; h--)m[k[h].name] = k[h].value;
                        g = a.a.c(g);
                        var s = w.createElement("form");
                        s.style.display = "none";
                        s.action = f;
                        s.method = "post";
                        for (var p in g)c = w.createElement("input"), c.type = "hidden", c.name = p, c.value = a.a.jb(a.a.c(g[p])), s.appendChild(c);
                        b(m, function(a, b) {
                            var c = w.createElement("input");
                            c.type = "hidden";
                            c.name = a;
                            c.value = b;
                            s.appendChild(c)
                        });
                        w.body.appendChild(s);
                        d.submitter ? d.submitter(s) : s.submit();
                        setTimeout(function() { s.parentNode.removeChild(s) },
                            0)
                    }
                }
            }();
            a.b("utils", a.a);
            a.b("utils.arrayForEach", a.a.o);
            a.b("utils.arrayFirst", a.a.vb);
            a.b("utils.arrayFilter", a.a.xa);
            a.b("utils.arrayGetDistinctValues", a.a.wb);
            a.b("utils.arrayIndexOf", a.a.m);
            a.b("utils.arrayMap", a.a.Ka);
            a.b("utils.arrayPushAll", a.a.ia);
            a.b("utils.arrayRemoveItem", a.a.ya);
            a.b("utils.extend", a.a.extend);
            a.b("utils.fieldsIncludedWithJsonPost", a.a.Bb);
            a.b("utils.getFormFields", a.a.Db);
            a.b("utils.peekObservable", a.a.cb);
            a.b("utils.postJson", a.a.zc);
            a.b("utils.parseJson", a.a.yc);
            a.b("utils.registerEventHandler",
                a.a.n);
            a.b("utils.stringifyJson", a.a.jb);
            a.b("utils.range", a.a.Bc);
            a.b("utils.toggleDomNodeCssClass", a.a.Ia);
            a.b("utils.triggerEvent", a.a.qa);
            a.b("utils.unwrapObservable", a.a.c);
            a.b("utils.objectForEach", a.a.A);
            a.b("utils.addOrRemoveItem", a.a.ga);
            a.b("utils.setTextContent", a.a.Ha);
            a.b("unwrap", a.a.c);
            Function.prototype.bind || (Function.prototype.bind = function(a) {
                var d = this;
                if (1 === arguments.length)return function() { return d.apply(a, arguments) };
                var c = Array.prototype.slice.call(arguments, 1);
                return function() {
                    var e =
                        c.slice(0);
                    e.push.apply(e, arguments);
                    return d.apply(a, e)
                }
            });
            a.a.f = new function() {
                function a(b, k) {
                    var h = b[c];
                    if (!h || "null" === h || !e[h]) {
                        if (!k)return p;
                        h = b[c] = "ko" + d++;
                        e[h] = {}
                    }
                    return e[h]
                }

                var d = 0, c = "__ko__" + (new Date).getTime(), e = {};
                return{
                    get: function(c, d) {
                        var e = a(c, !1);
                        return e === p ? p : e[d]
                    },
                    set: function(c, d, e) { if (e !== p || a(c, !1) !== p)a(c, !0)[d] = e },
                    clear: function(a) {
                        var b = a[c];
                        return b ? (delete e[b], a[c] = null, !0) : !1
                    },
                    I: function() { return d++ + c }
                }
            };
            a.b("utils.domData", a.a.f);
            a.b("utils.domData.clear", a.a.f.clear);
            a.a.C = new function() {
                function b(b, d) {
                    var e = a.a.f.get(b, c);
                    e === p && d && (e = [], a.a.f.set(b, c, e));
                    return e
                }

                function d(c) {
                    var e = b(c, !1);
                    if (e)for (var e = e.slice(0), l = 0; l < e.length; l++)e[l](c);
                    a.a.f.clear(c);
                    a.a.C.cleanExternalData(c);
                    if (f[c.nodeType])for (e = c.firstChild; c = e;)e = c.nextSibling, 8 === c.nodeType && d(c)
                }

                var c = a.a.f.I(), e = { 1: !0, 8: !0, 9: !0 }, f = { 1: !0, 9: !0 };
                return{
                    fa: function(a, c) {
                        if ("function" != typeof c)throw Error("Callback must be a function");
                        b(a, !0).push(c)
                    },
                    Pb: function(d, e) {
                        var f = b(d, !1);
                        f && (a.a.ya(f,
                            e), 0 == f.length && a.a.f.set(d, c, p))
                    },
                    S: function(b) {
                        if (e[b.nodeType] && (d(b), f[b.nodeType])) {
                            var c = [];
                            a.a.ia(c, b.getElementsByTagName("*"));
                            for (var l = 0, g = c.length; l < g; l++)d(c[l])
                        }
                        return b
                    },
                    removeNode: function(b) {
                        a.S(b);
                        b.parentNode && b.parentNode.removeChild(b)
                    },
                    cleanExternalData: function(a) { u && "function" == typeof u.cleanData && u.cleanData([a]) }
                }
            };
            a.S = a.a.C.S;
            a.removeNode = a.a.C.removeNode;
            a.b("cleanNode", a.S);
            a.b("removeNode", a.removeNode);
            a.b("utils.domNodeDisposal", a.a.C);
            a.b("utils.domNodeDisposal.addDisposeCallback",
                a.a.C.fa);
            a.b("utils.domNodeDisposal.removeDisposeCallback", a.a.C.Pb);
            (function() {
                a.a.ca = function(b, d) {
                    var c;
                    if (u)
                        if (u.parseHTML)c = u.parseHTML(b, d) || [];
                        else {
                            if ((c = u.clean([b], d)) && c[0]) {
                                for (var e = c[0]; e.parentNode && 11 !== e.parentNode.nodeType;)e = e.parentNode;
                                e.parentNode && e.parentNode.removeChild(e)
                            }
                        }
                    else {
                        (e = d) || (e = w);
                        c = e.parentWindow || e.defaultView || y;
                        var f = a.a.ib(b).toLowerCase(),
                            e = e.createElement("div"),
                            f = f.match(/^<(thead|tbody|tfoot)/) && [1, "<table>", "</table>"] || !f.indexOf("<tr") && [
                                2, "<table><tbody>",
                                "</tbody></table>"
                            ] || (!f.indexOf("<td") || !f.indexOf("<th")) && [3, "<table><tbody><tr>", "</tr></tbody></table>"] || [0, "", ""],
                            k = "ignored<div>" + f[1] + b + f[2] + "</div>";
                        for ("function" == typeof c.innerShiv ? e.appendChild(c.innerShiv(k)) : e.innerHTML = k; f[0]--;)e = e.lastChild;
                        c = a.a.O(e.lastChild.childNodes)
                    }
                    return c
                };
                a.a.gb = function(b, d) {
                    a.a.Ra(b);
                    d = a.a.c(d);
                    if (null !== d && d !== p)
                        if ("string" != typeof d && (d = d.toString()), u)u(b).html(d);
                        else for (var c = a.a.ca(d, b.ownerDocument), e = 0; e < c.length; e++)b.appendChild(c[e])
                }
            })();
            a.b("utils.parseHtmlFragment", a.a.ca);
            a.b("utils.setHtml", a.a.gb);
            a.H = function() {
                function b(c, d) {
                    if (c)
                        if (8 == c.nodeType) {
                            var f = a.H.Lb(c.nodeValue);
                            null != f && d.push({ ic: c, wc: f })
                        } else if (1 == c.nodeType)for (var f = 0, k = c.childNodes, h = k.length; f < h; f++)b(k[f], d)
                }

                var d = {};
                return{
                    $a: function(a) {
                        if ("function" != typeof a)throw Error("You can only pass a function to ko.memoization.memoize()");
                        var b = (4294967296 * (1 + Math.random()) | 0).toString(16).substring(1) + (4294967296 * (1 + Math.random()) | 0).toString(16).substring(1);
                        d[b] = a;
                        return"\x3c!--[ko_memo:" + b + "]--\x3e"
                    },
                    Wb: function(a, b) {
                        var f = d[a];
                        if (f === p)throw Error("Couldn't find any memo with ID " + a + ". Perhaps it's already been unmemoized.");
                        try {
                            return f.apply(null, b || []), !0
                        } finally {
                            delete d[a]
                        }
                    },
                    Xb: function(c, d) {
                        var f = [];
                        b(c, f);
                        for (var k = 0, h = f.length; k < h; k++) {
                            var l = f[k].ic, g = [l];
                            d && a.a.ia(g, d);
                            a.H.Wb(f[k].wc, g);
                            l.nodeValue = "";
                            l.parentNode && l.parentNode.removeChild(l)
                        }
                    },
                    Lb: function(a) { return(a = a.match(/^\[ko_memo\:(.*?)\]$/)) ? a[1] : null }
                }
            }();
            a.b("memoization", a.H);
            a.b("memoization.memoize", a.H.$a);
            a.b("memoization.unmemoize", a.H.Wb);
            a.b("memoization.parseMemoText", a.H.Lb);
            a.b("memoization.unmemoizeDomNodeAndDescendants", a.H.Xb);
            a.Sa = {
                throttle: function(b, d) {
                    b.throttleEvaluation = d;
                    var c = null;
                    return a.j({
                        read: b,
                        write: function(a) {
                            clearTimeout(c);
                            c = setTimeout(function() { b(a) }, d)
                        }
                    })
                },
                rateLimit: function(a, d) {
                    var c, e, f;
                    "number" == typeof d ? c = d : (c = d.timeout, e = d.method);
                    f = "notifyWhenChangesStop" == e ? S : R;
                    a.Za(function(a) { return f(a, c) })
                },
                notify: function(a, d) {
                    a.equalityComparer =
                        "always" == d ? null : J
                }
            };
            var Q = { undefined: 1, "boolean": 1, number: 1, string: 1 };
            a.b("extenders", a.Sa);
            a.Ub = function(b, d, c) {
                this.da = b;
                this.La = d;
                this.hc = c;
                this.Gb = !1;
                a.D(this, "dispose", this.p)
            };
            a.Ub.prototype.p = function() {
                this.Gb = !0;
                this.hc()
            };
            a.Q = function() {
                a.a.Ga(this, a.Q.fn);
                this.G = {};
                this.rb = 1
            };
            var z = {
                U: function(b, d, c) {
                    var e = this;
                    c = c || "change";
                    var f = new a.Ub(e, d ? b.bind(d) : b, function() {
                        a.a.ya(e.G[c], f);
                        e.ua && e.ua(c)
                    });
                    e.ja && e.ja(c);
                    e.G[c] || (e.G[c] = []);
                    e.G[c].push(f);
                    return f
                },
                notifySubscribers: function(b,
                    d) {
                    d = d || "change";
                    "change" === d && this.Yb();
                    if (this.Ba(d))
                        try {
                            a.k.xb();
                            for (var c = this.G[d].slice(0), e = 0, f; f = c[e]; ++e)f.Gb || f.La(b)
                        } finally {
                            a.k.end()
                        }
                },
                Aa: function() { return this.rb },
                pc: function(a) { return this.Aa() !== a },
                Yb: function() { ++this.rb },
                Za: function(b) {
                    var d = this, c = a.F(d), e, f, k;
                    d.ta || (d.ta = d.notifySubscribers, d.notifySubscribers = function(a, b) { b && "change" !== b ? "beforeChange" === b ? d.pb(a) : d.ta(a, b) : d.qb(a) });
                    var h = b(function() {
                        c && k === d && (k = d());
                        e = !1;
                        d.Wa(f, k) && d.ta(f = k)
                    });
                    d.qb = function(a) {
                        e = !0;
                        k = a;
                        h()
                    };
                    d.pb = function(a) { e || (f = a, d.ta(a, "beforeChange")) }
                },
                Ba: function(a) { return this.G[a] && this.G[a].length },
                nc: function(b) {
                    if (b)return this.G[b] && this.G[b].length || 0;
                    var d = 0;
                    a.a.A(this.G, function(a, b) { d += b.length });
                    return d
                },
                Wa: function(a, d) { return!this.equalityComparer || !this.equalityComparer(a, d) },
                extend: function(b) {
                    var d = this;
                    b && a.a.A(b, function(b, e) {
                        var f = a.Sa[b];
                        "function" == typeof f && (d = f(d, e) || d)
                    });
                    return d
                }
            };
            a.D(z, "subscribe", z.U);
            a.D(z, "extend", z.extend);
            a.D(z, "getSubscriptionsCount", z.nc);
            a.a.za && a.a.Fa(z, Function.prototype);
            a.Q.fn = z;
            a.Hb = function(a) { return null != a && "function" == typeof a.U && "function" == typeof a.notifySubscribers };
            a.b("subscribable", a.Q);
            a.b("isSubscribable", a.Hb);
            a.Z = a.k = function() {
                function b(a) {
                    c.push(e);
                    e = a
                }

                function d() { e = c.pop() }

                var c = [], e, f = 0;
                return{
                    xb: b,
                    end: d,
                    Ob: function(b) {
                        if (e) {
                            if (!a.Hb(b))throw Error("Only subscribable things can act as dependencies");
                            e.La(b, b.ac || (b.ac = ++f))
                        }
                    },
                    u: function(a, c, e) {
                        try {
                            return b(), a.apply(c, e || [])
                        } finally {
                            d()
                        }
                    },
                    oa: function() { if (e)return e.w.oa() },
                    Ca: function() { if (e)return e.Ca }
                }
            }();
            a.b("computedContext", a.Z);
            a.b("computedContext.getDependenciesCount", a.Z.oa);
            a.b("computedContext.isInitial", a.Z.Ca);
            a.b("computedContext.isSleeping", a.Z.Jc);
            a.b("ignoreDependencies", a.Gc = a.k.u);
            a.r = function(b) {
                function d() {
                    if (0 < arguments.length)return d.Wa(c, arguments[0]) && (d.X(), c = arguments[0], d.W()), this;
                    a.k.Ob(d);
                    return c
                }

                var c = b;
                a.Q.call(d);
                a.a.Ga(d, a.r.fn);
                d.B = function() { return c };
                d.W = function() { d.notifySubscribers(c) };
                d.X = function() {
                    d.notifySubscribers(c,
                        "beforeChange")
                };
                a.D(d, "peek", d.B);
                a.D(d, "valueHasMutated", d.W);
                a.D(d, "valueWillMutate", d.X);
                return d
            };
            a.r.fn = { equalityComparer: J };
            var H = a.r.Ac = "__ko_proto__";
            a.r.fn[H] = a.r;
            a.a.za && a.a.Fa(a.r.fn, a.Q.fn);
            a.Ta = function(b, d) { return null === b || b === p || b[H] === p ? !1 : b[H] === d ? !0 : a.Ta(b[H], d) };
            a.F = function(b) { return a.Ta(b, a.r) };
            a.Da = function(b) { return"function" == typeof b && b[H] === a.r || "function" == typeof b && b[H] === a.j && b.qc ? !0 : !1 };
            a.b("observable", a.r);
            a.b("isObservable", a.F);
            a.b("isWriteableObservable", a.Da);
            a.b("isWritableObservable", a.Da);
            a.ba = function(b) {
                b = b || [];
                if ("object" != typeof b || !("length" in b))throw Error("The argument passed when initializing an observable array must be an array, or null, or undefined.");
                b = a.r(b);
                a.a.Ga(b, a.ba.fn);
                return b.extend({ trackArrayChanges: !0 })
            };
            a.ba.fn = {
                remove: function(b) {
                    for (var d = this.B(), c = [], e = "function" != typeof b || a.F(b) ? function(a) { return a === b } : b, f = 0; f < d.length; f++) {
                        var k = d[f];
                        e(k) && (0 === c.length && this.X(), c.push(k), d.splice(f, 1), f--)
                    }
                    c.length && this.W();
                    return c
                },
                removeAll: function(b) {
                    if (b === p) {
                        var d = this.B(), c = d.slice(0);
                        this.X();
                        d.splice(0, d.length);
                        this.W();
                        return c
                    }
                    return b ? this.remove(function(c) { return 0 <= a.a.m(b, c) }) : []
                },
                destroy: function(b) {
                    var d = this.B(), c = "function" != typeof b || a.F(b) ? function(a) { return a === b } : b;
                    this.X();
                    for (var e = d.length - 1; 0 <= e; e--)c(d[e]) && (d[e]._destroy = !0);
                    this.W()
                },
                destroyAll: function(b) { return b === p ? this.destroy(function() { return!0 }) : b ? this.destroy(function(d) { return 0 <= a.a.m(b, d) }) : [] },
                indexOf: function(b) {
                    var d = this();
                    return a.a.m(d,
                        b)
                },
                replace: function(a, d) {
                    var c = this.indexOf(a);
                    0 <= c && (this.X(), this.B()[c] = d, this.W())
                }
            };
            a.a.o("pop push reverse shift sort splice unshift".split(" "), function(b) {
                a.ba.fn[b] = function() {
                    var a = this.B();
                    this.X();
                    this.yb(a, b, arguments);
                    a = a[b].apply(a, arguments);
                    this.W();
                    return a
                }
            });
            a.a.o(["slice"], function(b) {
                a.ba.fn[b] = function() {
                    var a = this();
                    return a[b].apply(a, arguments)
                }
            });
            a.a.za && a.a.Fa(a.ba.fn, a.r.fn);
            a.b("observableArray", a.ba);
            a.Sa.trackArrayChanges = function(b) {
                function d() {
                    if (!c) {
                        c = !0;
                        var g =
                            b.notifySubscribers;
                        b.notifySubscribers = function(a, b) {
                            b && "change" !== b || ++k;
                            return g.apply(this, arguments)
                        };
                        var d = [].concat(b.B() || []);
                        e = null;
                        f = b.U(function(c) {
                            c = [].concat(c || []);
                            if (b.Ba("arrayChange")) {
                                var g;
                                if (!e || 1 < k)e = a.a.Ma(d, c, { sparse: !0 });
                                g = e
                            }
                            d = c;
                            e = null;
                            k = 0;
                            g && g.length && b.notifySubscribers(g, "arrayChange")
                        })
                    }
                }

                if (!b.yb) {
                    var c = !1, e = null, f, k = 0, h = b.ja, l = b.ua;
                    b.ja = function(a) {
                        h && h.call(b, a);
                        "arrayChange" === a && d()
                    };
                    b.ua = function(a) {
                        l && l.call(b, a);
                        "arrayChange" !== a || b.Ba("arrayChange") || (f.p(), c = !1)
                    };
                    b.yb = function(b, d, f) {
                        function l(a, b, c) { return h[h.length] = { status: a, value: b, index: c } }

                        if (c && !k) {
                            var h = [], r = b.length, v = f.length, t = 0;
                            switch (d) {
                            case "push":
                                t = r;
                            case "unshift":
                                for (d = 0; d < v; d++)l("added", f[d], t + d);
                                break;
                            case "pop":
                                t = r - 1;
                            case "shift":
                                r && l("deleted", b[t], t);
                                break;
                            case "splice":
                                d = Math.min(Math.max(0, 0 > f[0] ? r + f[0] : f[0]), r);
                                for (var r = 1 === v ? r : Math.min(d + (f[1] || 0), r), v = d + v - 2, t = Math.max(r, v), G = [], A = [], p = 2; d < t; ++d, ++p)d < r && A.push(l("deleted", b[d], d)), d < v && G.push(l("added", f[p], d));
                                a.a.Cb(A, G);
                                break;
                            default:
                                return
                            }
                            e = h
                        }
                    }
                }
            };
            a.w = a.j = function(b, d, c) {
                function e(a, b, c) {
                    if (I && b === g)throw Error("A 'pure' computed must not be called recursively");
                    B[a] = c;
                    c.sa = F++;
                    c.ea = b.Aa()
                }

                function f() {
                    var a, b;
                    for (a in B)if (B.hasOwnProperty(a) && (b = B[a], b.da.pc(b.ea)))return!0
                }

                function k() {
                    !s && B && a.a.A(B, function(a, b) { b.p && b.p() });
                    B = null;
                    F = 0;
                    G = !0;
                    s = r = !1
                }

                function h() {
                    var a = g.throttleEvaluation;
                    a && 0 <= a ? (clearTimeout(z), z = setTimeout(function() { l(!0) }, a)) : g.nb ? g.nb() : l(!0)
                }

                function l(b) {
                    if (!v && !G) {
                        if (y && y()) {
                            if (!t) {
                                w();
                                return
                            }
                        } else
                            t =
                                !1;
                        v = !0;
                        try {
                            var c = B, m = F, f = I ? p : !F;
                            a.k.xb({ La: function(a, b) { G || (m && c[b] ? (e(b, a, c[b]), delete c[b], --m) : B[b] || e(b, a, s ? { da: a } : a.U(h))) }, w: g, Ca: f });
                            B = {};
                            F = 0;
                            try {
                                var l = d ? A.call(d) : A()
                            } finally {
                                a.k.end(), m && !s && a.a.A(c, function(a, b) { b.p && b.p() }), r = !1
                            }
                            g.Wa(n, l) && (s || q(n, "beforeChange"), n = l, s ? g.Yb() : b && q(n));
                            f && q(n, "awake")
                        } finally {
                            v = !1
                        }
                        F || w()
                    }
                }

                function g() {
                    if (0 < arguments.length) {
                        if ("function" === typeof C)C.apply(d, arguments);
                        else throw Error("Cannot write a value to a ko.computed unless you specify a 'write' option. If you wish to read the current value, don't pass any parameters.");
                        return this
                    }
                    a.k.Ob(g);
                    (r || s && f()) && l();
                    return n
                }

                function m() {
                    (r && !F || s && f()) && l();
                    return n
                }

                function x() { return r || 0 < F }

                function q(a, b) { g.notifySubscribers(a, b) }

                var n, r = !0, v = !1, t = !1, G = !1, A = b, I = !1, s = !1;
                A && "object" == typeof A ? (c = A, A = c.read) : (c = c || {}, A || (A = c.read));
                if ("function" != typeof A)throw Error("Pass a function that returns the value of the ko.computed");
                var C = c.write, D = c.disposeWhenNodeIsRemoved || c.q || null, u = c.disposeWhen || c.Pa, y = u, w = k, B = {}, F = 0, z = null;
                d || (d = c.owner);
                a.Q.call(g);
                a.a.Ga(g, a.j.fn);
                g.B = m;
                g.oa = function() { return F };
                g.qc = "function" === typeof C;
                g.p = function() { w() };
                g.$ = x;
                var T = g.Za;
                g.Za = function(a) {
                    T.call(g, a);
                    g.nb = function() {
                        g.pb(n);
                        r = !0;
                        g.qb(g)
                    }
                };
                c.pure ? (s = I = !0, g.ja = function(b) {
                    if (!G && s && "change" == b) {
                        s = !1;
                        if (r || f())B = null, F = 0, r = !0, l();
                        else {
                            var c = [];
                            a.a.A(B, function(a, b) { c[b.sa] = a });
                            a.a.o(c, function(a, b) {
                                var c = B[a], g = c.da.U(h);
                                g.sa = b;
                                g.ea = c.ea;
                                B[a] = g
                            })
                        }
                        G || q(n, "awake")
                    }
                }, g.ua = function(b) {
                    G || "change" != b || g.Ba("change") || (a.a.A(B, function(a, b) { b.p && (B[a] = { da: b.da, sa: b.sa, ea: b.ea }, b.p()) }),
                        s = !0, q(p, "asleep"))
                }, g.bc = g.Aa, g.Aa = function() {
                    s && (r || f()) && l();
                    return g.bc()
                }) : c.deferEvaluation && (g.ja = function(a) { "change" != a && "beforeChange" != a || m() });
                a.D(g, "peek", g.B);
                a.D(g, "dispose", g.p);
                a.D(g, "isActive", g.$);
                a.D(g, "getDependenciesCount", g.oa);
                D && (t = !0, D.nodeType && (y = function() { return!a.a.Qa(D) || u && u() }));
                s || c.deferEvaluation || l();
                D && x() && D.nodeType && (w = function() {
                    a.a.C.Pb(D, w);
                    k()
                }, a.a.C.fa(D, w));
                return g
            };
            a.sc = function(b) { return a.Ta(b, a.j) };
            z = a.r.Ac;
            a.j[z] = a.r;
            a.j.fn = { equalityComparer: J };
            a.j.fn[z] = a.j;
            a.a.za && a.a.Fa(a.j.fn, a.Q.fn);
            a.b("dependentObservable", a.j);
            a.b("computed", a.j);
            a.b("isComputed", a.sc);
            a.Nb = function(b, d) {
                if ("function" === typeof b)return a.w(b, d, { pure: !0 });
                b = a.a.extend({}, b);
                b.pure = !0;
                return a.w(b, d)
            };
            a.b("pureComputed", a.Nb);
            (function() {
                function b(a, f, k) {
                    k = k || new c;
                    a = f(a);
                    if ("object" != typeof a || null === a || a === p || a instanceof Date || a instanceof String || a instanceof Number || a instanceof Boolean)return a;
                    var h = a instanceof Array ? [] : {};
                    k.save(a, h);
                    d(a, function(c) {
                        var g =
                            f(a[c]);
                        switch (typeof g) {
                        case "boolean":
                        case "number":
                        case "string":
                        case "function":
                            h[c] = g;
                            break;
                        case "object":
                        case "undefined":
                            var d = k.get(g);
                            h[c] = d !== p ? d : b(g, f, k)
                        }
                    });
                    return h
                }

                function d(a, b) {
                    if (a instanceof Array) {
                        for (var c = 0; c < a.length; c++)b(c);
                        "function" == typeof a.toJSON && b("toJSON")
                    } else for (c in a)b(c)
                }

                function c() {
                    this.keys = [];
                    this.mb = []
                }

                a.Vb = function(c) {
                    if (0 == arguments.length)throw Error("When calling ko.toJS, pass the object you want to convert.");
                    return b(c, function(b) {
                        for (var c = 0; a.F(b) &&
                            10 > c; c++)b = b();
                        return b
                    })
                };
                a.toJSON = function(b, c, d) {
                    b = a.Vb(b);
                    return a.a.jb(b, c, d)
                };
                c.prototype = {
                    save: function(b, c) {
                        var d = a.a.m(this.keys, b);
                        0 <= d ? this.mb[d] = c : (this.keys.push(b), this.mb.push(c))
                    },
                    get: function(b) {
                        b = a.a.m(this.keys, b);
                        return 0 <= b ? this.mb[b] : p
                    }
                }
            })();
            a.b("toJS", a.Vb);
            a.b("toJSON", a.toJSON);
            (function() {
                a.i = {
                    s: function(b) {
                        switch (a.a.v(b)) {
                        case "option":
                            return!0 === b.__ko__hasDomDataOptionValue__ ? a.a.f.get(b, a.d.options.ab) : 7 >= a.a.M ? b.getAttributeNode("value") && b.getAttributeNode("value").specified ?
                                b.value : b.text : b.value;
                        case "select":
                            return 0 <= b.selectedIndex ? a.i.s(b.options[b.selectedIndex]) : p;
                        default:
                            return b.value
                        }
                    },
                    Y: function(b, d, c) {
                        switch (a.a.v(b)) {
                        case "option":
                            switch (typeof d) {
                            case "string":
                                a.a.f.set(b, a.d.options.ab, p);
                                "__ko__hasDomDataOptionValue__" in b && delete b.__ko__hasDomDataOptionValue__;
                                b.value = d;
                                break;
                            default:
                                a.a.f.set(b, a.d.options.ab, d), b.__ko__hasDomDataOptionValue__ = !0, b.value = "number" === typeof d ? d : ""
                            }
                            break;
                        case "select":
                            if ("" === d || null === d)d = p;
                            for (var e = -1,
                                f = 0,
                                k = b.options.length,
                                h; f < k; ++f)
                                if (h = a.i.s(b.options[f]), h == d || "" == h && d === p) {
                                    e = f;
                                    break
                                }
                            if (c || 0 <= e || d === p && 1 < b.size)b.selectedIndex = e;
                            break;
                        default:
                            if (null === d || d === p)d = "";
                            b.value = d
                        }
                    }
                }
            })();
            a.b("selectExtensions", a.i);
            a.b("selectExtensions.readValue", a.i.s);
            a.b("selectExtensions.writeValue", a.i.Y);
            a.h = function() {
                function b(b) {
                    b = a.a.ib(b);
                    123 === b.charCodeAt(0) && (b = b.slice(1, -1));
                    var c = [], d = b.match(e), x, h = [], n = 0;
                    if (d) {
                        d.push(",");
                        for (var r = 0, v; v = d[r]; ++r) {
                            var t = v.charCodeAt(0);
                            if (44 === t) {
                                if (0 >= n) {
                                    c.push(x && h.length ? {
                                        key: x,
                                        value: h.join("")
                                    } : { unknown: x || h.join("") });
                                    x = n = 0;
                                    h = [];
                                    continue
                                }
                            } else if (58 === t) {
                                if (!n && !x && 1 === h.length) {
                                    x = h.pop();
                                    continue
                                }
                            } else 47 === t && r && 1 < v.length ? (t = d[r - 1].match(f)) && !k[t[0]] && (b = b.substr(b.indexOf(v) + 1), d = b.match(e), d.push(","), r = -1, v = "/") : 40 === t || 123 === t || 91 === t ? ++n : 41 === t || 125 === t || 93 === t ? --n : x || h.length || 34 !== t && 39 !== t || (v = v.slice(1, -1));
                            h.push(v)
                        }
                    }
                    return c
                }

                var d = ["true", "false", "null", "undefined"],
                    c = /^(?:[$_a-z][$\w]*|(.+)(\.\s*[$_a-z][$\w]*|\[.+\]))$/i,
                    e = RegExp("\"(?:[^\"\\\\]|\\\\.)*\"|'(?:[^'\\\\]|\\\\.)*'|/(?:[^/\\\\]|\\\\.)*/w*|[^\\s:,/][^,\"'{}()/:[\\]]*[^\\s,\"'{}()/:[\\]]|[^\\s]",
                        "g"),
                    f = /[\])"'A-Za-z0-9_$]+$/,
                    k = { "in": 1, "return": 1, "typeof": 1 },
                    h = {};
                return{
                    ka: [],
                    V: h,
                    bb: b,
                    Ea: function(e, g) {
                        function m(b, g) {
                            var e;
                            if (!r) {
                                var l = a.getBindingHandler(b);
                                if (l && l.preprocess && !(g = l.preprocess(g, b, m)))return;
                                if (l = h[b])e = g, 0 <= a.a.m(d, e) ? e = !1 : (l = e.match(c), e = null === l ? !1 : l[1] ? "Object(" + l[1] + ")" + l[2] : e), l = e;
                                l && k.push("'" + b + "':function(_z){" + e + "=_z}")
                            }
                            n && (g = "function(){return " + g + " }");
                            f.push("'" + b + "':" + g)
                        }

                        g = g || {};
                        var f = [], k = [], n = g.valueAccessors, r = g.bindingParams, v = "string" === typeof e ? b(e) : e;
                        a.a.o(v, function(a) { m(a.key || a.unknown, a.value) });
                        k.length && m("_ko_property_writers", "{" + k.join(",") + " }");
                        return f.join(",")
                    },
                    vc: function(a, b) {
                        for (var c = 0; c < a.length; c++)if (a[c].key == b)return!0;
                        return!1
                    },
                    ra: function(b, c, d, e, f) {
                        if (b && a.F(b))!a.Da(b) || f && b.B() === e || b(e);
                        else if ((b = c.get("_ko_property_writers")) && b[d])b[d](e)
                    }
                }
            }();
            a.b("expressionRewriting", a.h);
            a.b("expressionRewriting.bindingRewriteValidators", a.h.ka);
            a.b("expressionRewriting.parseObjectLiteral", a.h.bb);
            a.b("expressionRewriting.preProcessBindings",
                a.h.Ea);
            a.b("expressionRewriting._twoWayBindings", a.h.V);
            a.b("jsonExpressionRewriting", a.h);
            a.b("jsonExpressionRewriting.insertPropertyAccessorsIntoJson", a.h.Ea);
            (function() {
                function b(a) { return 8 == a.nodeType && k.test(f ? a.text : a.nodeValue) }

                function d(a) { return 8 == a.nodeType && h.test(f ? a.text : a.nodeValue) }

                function c(a, c) {
                    for (var e = a, f = 1, l = []; e = e.nextSibling;) {
                        if (d(e) && (f--, 0 === f))return l;
                        l.push(e);
                        b(e) && f++
                    }
                    if (!c)throw Error("Cannot find closing comment tag to match: " + a.nodeValue);
                    return null
                }

                function e(a,
                    b) {
                    var d = c(a, b);
                    return d ? 0 < d.length ? d[d.length - 1].nextSibling : a.nextSibling : null
                }

                var f = w && "\x3c!--test--\x3e" === w.createComment("test").text, k = f ? /^\x3c!--\s*ko(?:\s+([\s\S]+))?\s*--\x3e$/ : /^\s*ko(?:\s+([\s\S]+))?\s*$/, h = f ? /^\x3c!--\s*\/ko\s*--\x3e$/ : /^\s*\/ko\s*$/, l = { ul: !0, ol: !0 };
                a.e = {
                    R: {},
                    childNodes: function(a) { return b(a) ? c(a) : a.childNodes },
                    ma: function(c) {
                        if (b(c)) {
                            c = a.e.childNodes(c);
                            for (var d = 0, e = c.length; d < e; d++)a.removeNode(c[d])
                        } else a.a.Ra(c)
                    },
                    T: function(c, d) {
                        if (b(c)) {
                            a.e.ma(c);
                            for (var e = c.nextSibling,
                                f = 0,
                                l = d.length; f < l; f++)e.parentNode.insertBefore(d[f], e)
                        } else a.a.T(c, d)
                    },
                    Mb: function(a, c) { b(a) ? a.parentNode.insertBefore(c, a.nextSibling) : a.firstChild ? a.insertBefore(c, a.firstChild) : a.appendChild(c) },
                    Fb: function(c, d, e) { e ? b(c) ? c.parentNode.insertBefore(d, e.nextSibling) : e.nextSibling ? c.insertBefore(d, e.nextSibling) : c.appendChild(d) : a.e.Mb(c, d) },
                    firstChild: function(a) { return b(a) ? !a.nextSibling || d(a.nextSibling) ? null : a.nextSibling : a.firstChild },
                    nextSibling: function(a) {
                        b(a) && (a = e(a));
                        return a.nextSibling &&
                            d(a.nextSibling) ? null : a.nextSibling
                    },
                    oc: b,
                    Fc: function(a) { return(a = (f ? a.text : a.nodeValue).match(k)) ? a[1] : null },
                    Kb: function(c) {
                        if (l[a.a.v(c)]) {
                            var m = c.firstChild;
                            if (m) {
                                do
                                    if (1 === m.nodeType) {
                                        var f;
                                        f = m.firstChild;
                                        var h = null;
                                        if (f) {
                                            do
                                                if (h)h.push(f);
                                                else if (b(f)) {
                                                    var k = e(f, !0);
                                                    k ? f = k : h = [f]
                                                } else d(f) && (h = [f]);
                                            while (f = f.nextSibling)
                                        }
                                        if (f = h)for (h = m.nextSibling, k = 0; k < f.length; k++)h ? c.insertBefore(f[k], h) : c.appendChild(f[k])
                                    }
                                while (m = m.nextSibling)
                            }
                        }
                    }
                }
            })();
            a.b("virtualElements", a.e);
            a.b("virtualElements.allowedBindings",
                a.e.R);
            a.b("virtualElements.emptyNode", a.e.ma);
            a.b("virtualElements.insertAfter", a.e.Fb);
            a.b("virtualElements.prepend", a.e.Mb);
            a.b("virtualElements.setDomNodeChildren", a.e.T);
            (function() {
                a.L = function() { this.ec = {} };
                a.a.extend(a.L.prototype, {
                    nodeHasBindings: function(b) {
                        switch (b.nodeType) {
                        case 1:
                            return null != b.getAttribute("data-bind") || a.g.getComponentNameForNode(b);
                        case 8:
                            return a.e.oc(b);
                        default:
                            return!1
                        }
                    },
                    getBindings: function(b, d) {
                        var c = this.getBindingsString(b, d),
                            c = c ? this.parseBindingsString(c,
                                d, b) : null;
                        return a.g.sb(c, b, d, !1)
                    },
                    getBindingAccessors: function(b, d) {
                        var c = this.getBindingsString(b, d), c = c ? this.parseBindingsString(c, d, b, { valueAccessors: !0 }) : null;
                        return a.g.sb(c, b, d, !0)
                    },
                    getBindingsString: function(b) {
                        switch (b.nodeType) {
                        case 1:
                            return b.getAttribute("data-bind");
                        case 8:
                            return a.e.Fc(b);
                        default:
                            return null
                        }
                    },
                    parseBindingsString: function(b, d, c, e) {
                        try {
                            var f = this.ec, k = b + (e && e.valueAccessors || ""), h;
                            if (!(h = f[k])) {
                                var l, g = "with($context){with($data||{}){return{" + a.h.Ea(b, e) + "}}}";
                                l = new Function("$context",
                                    "$element", g);
                                h = f[k] = l
                            }
                            return h(d, c)
                        } catch (m) {
                            throw m.message = "Unable to parse bindings.\nBindings value: " + b + "\nMessage: " + m.message, m;
                        }
                    }
                });
                a.L.instance = new a.L
            })();
            a.b("bindingProvider", a.L);
            (function() {
                function b(a) { return function() { return a } }

                function d(a) { return a() }

                function c(b) { return a.a.pa(a.k.u(b), function(a, c) { return function() { return b()[c] } }) }

                function e(d, g, e) { return"function" === typeof d ? c(d.bind(null, g, e)) : a.a.pa(d, b) }

                function f(a, b) { return c(this.getBindings.bind(this, a, b)) }

                function k(b,
                    c, d) {
                    var g, e = a.e.firstChild(c), f = a.L.instance, m = f.preprocessNode;
                    if (m) {
                        for (; g = e;)e = a.e.nextSibling(g), m.call(f, g);
                        e = a.e.firstChild(c)
                    }
                    for (; g = e;)e = a.e.nextSibling(g), h(b, g, d)
                }

                function h(b, c, d) {
                    var e = !0, f = 1 === c.nodeType;
                    f && a.e.Kb(c);
                    if (f && d || a.L.instance.nodeHasBindings(c))e = g(c, null, b, d).shouldBindDescendants;
                    e && !x[a.a.v(c)] && k(b, c, !f)
                }

                function l(b) {
                    var c = [], d = {}, g = [];
                    a.a.A(b, function I(e) {
                        if (!d[e]) {
                            var f = a.getBindingHandler(e);
                            f && (f.after && (g.push(e), a.a.o(f.after, function(c) {
                                if (b[c]) {
                                    if (-1 !== a.a.m(g,
                                        c))throw Error("Cannot combine the following bindings, because they have a cyclic dependency: " + g.join(", "));
                                    I(c)
                                }
                            }), g.length--), c.push({ key: e, Eb: f }));
                            d[e] = !0
                        }
                    });
                    return c
                }

                function g(b, c, g, e) {
                    var m = a.a.f.get(b, q);
                    if (!c) {
                        if (m)throw Error("You cannot apply bindings multiple times to the same element.");
                        a.a.f.set(b, q, !0)
                    }
                    !m && e && a.Tb(b, g);
                    var h;
                    if (c && "function" !== typeof c)h = c;
                    else {
                        var k = a.L.instance, x = k.getBindingAccessors || f,
                            n = a.j(function() {
                                (h = c ? c(g, b) : x.call(k, b, g)) && g.K && g.K();
                                return h
                            }, null, { q: b });
                        h && n.$() || (n = null)
                    }
                    var u;
                    if (h) {
                        var w = n ? function(a) { return function() { return d(n()[a]) } } : function(a) { return h[a] }, y = function() { return a.a.pa(n ? n() : h, d) };
                        y.get = function(a) { return h[a] && d(w(a)) };
                        y.has = function(a) { return a in h };
                        e = l(h);
                        a.a.o(e, function(c) {
                            var d = c.Eb.init, e = c.Eb.update, f = c.key;
                            if (8 === b.nodeType && !a.e.R[f])throw Error("The binding '" + f + "' cannot be used with virtual elements");
                            try {
                                "function" == typeof d && a.k.u(function() {
                                    var a = d(b, w(f), y, g.$data, g);
                                    if (a && a.controlsDescendantBindings) {
                                        if (u !==
                                            p)throw Error("Multiple bindings (" + u + " and " + f + ") are trying to control descendant bindings of the same element. You cannot use these bindings together on the same element.");
                                        u = f
                                    }
                                }), "function" == typeof e && a.j(function() { e(b, w(f), y, g.$data, g) }, null, { q: b })
                            } catch (m) {
                                throw m.message = 'Unable to process binding "' + f + ": " + h[f] + '"\nMessage: ' + m.message, m;
                            }
                        })
                    }
                    return{ shouldBindDescendants: u === p }
                }

                function m(b) { return b && b instanceof a.N ? b : new a.N(b) }

                a.d = {};
                var x = { script: !0, textarea: !0 };
                a.getBindingHandler = function(b) { return a.d[b] };
                a.N = function(b, c, d, g) {
                    var e = this, f = "function" == typeof b && !a.F(b), m,
                        l = a.j(function() {
                            var m = f ? b() : b, h = a.a.c(m);
                            c ? (c.K && c.K(), a.a.extend(e, c), l && (e.K = l)) : (e.$parents = [], e.$root = h, e.ko = a);
                            e.$rawData = m;
                            e.$data = h;
                            d && (e[d] = h);
                            g && g(e, c, h);
                            return e.$data
                        }, null, { Pa: function() { return m && !a.a.tb(m) }, q: !0 });
                    l.$() && (e.K = l, l.equalityComparer = null, m = [], l.Zb = function(b) {
                        m.push(b);
                        a.a.C.fa(b, function(b) {
                            a.a.ya(m, b);
                            m.length || (l.p(), e.K = l = p)
                        })
                    })
                };
                a.N.prototype.createChildContext = function(b, c, d) {
                    return new a.N(b, this,
                        c, function(a, b) {
                            a.$parentContext = b;
                            a.$parent = b.$data;
                            a.$parents = (b.$parents || []).slice(0);
                            a.$parents.unshift(a.$parent);
                            d && d(a)
                        })
                };
                a.N.prototype.extend = function(b) {
                    return new a.N(this.K || this.$data, this, null, function(c, d) {
                        c.$rawData = d.$rawData;
                        a.a.extend(c, "function" == typeof b ? b() : b)
                    })
                };
                var q = a.a.f.I(), n = a.a.f.I();
                a.Tb = function(b, c) {
                    if (2 == arguments.length)a.a.f.set(b, n, c), c.K && c.K.Zb(b);
                    else return a.a.f.get(b, n)
                };
                a.va = function(b, c, d) {
                    1 === b.nodeType && a.e.Kb(b);
                    return g(b, c, m(d), !0)
                };
                a.cc = function(b,
                    c, d) {
                    d = m(d);
                    return a.va(b, e(c, d, b), d)
                };
                a.Ja = function(a, b) { 1 !== b.nodeType && 8 !== b.nodeType || k(m(a), b, !0) };
                a.ub = function(a, b) {
                    !u && y.jQuery && (u = y.jQuery);
                    if (b && 1 !== b.nodeType && 8 !== b.nodeType)throw Error("ko.applyBindings: first parameter should be your view model; second parameter should be a DOM node");
                    b = b || y.document.body;
                    h(m(a), b, !0)
                };
                a.Oa = function(b) {
                    switch (b.nodeType) {
                    case 1:
                    case 8:
                        var c = a.Tb(b);
                        if (c)return c;
                        if (b.parentNode)return a.Oa(b.parentNode)
                    }
                    return p
                };
                a.gc = function(b) {
                    return(b = a.Oa(b)) ?
                        b.$data : p
                };
                a.b("bindingHandlers", a.d);
                a.b("applyBindings", a.ub);
                a.b("applyBindingsToDescendants", a.Ja);
                a.b("applyBindingAccessorsToNode", a.va);
                a.b("applyBindingsToNode", a.cc);
                a.b("contextFor", a.Oa);
                a.b("dataFor", a.gc)
            })();
            (function(b) {
                function d(d, e) {
                    var g = f.hasOwnProperty(d) ? f[d] : b, m;
                    g ? g.U(e) : (g = f[d] = new a.Q, g.U(e), c(d, function(a, b) {
                        var c = !(!b || !b.synchronous);
                        k[d] = { definition: a, tc: c };
                        delete f[d];
                        m || c ? g.notifySubscribers(a) : setTimeout(function() { g.notifySubscribers(a) }, 0)
                    }), m = !0)
                }

                function c(a, b) {
                    e("getConfig",
                    [a], function(c) { c ? e("loadComponent", [a, c], function(a) { b(a, c) }) : b(null, null) })
                }

                function e(c, d, g, f) {
                    f || (f = a.g.loaders.slice(0));
                    var k = f.shift();
                    if (k) {
                        var q = k[c];
                        if (q) {
                            var n = !1;
                            if (q.apply(k, d.concat(function(a) { n ? g(null) : null !== a ? g(a) : e(c, d, g, f) })) !== b && (n = !0, !k.suppressLoaderExceptions))throw Error("Component loaders must supply values by invoking the callback, not by returning values synchronously.");
                        } else e(c, d, g, f)
                    } else g(null)
                }

                var f = {}, k = {};
                a.g = {
                    get: function(c, e) {
                        var g = k.hasOwnProperty(c) ? k[c] :
                            b;
                        g ? g.tc ? a.k.u(function() { e(g.definition) }) : setTimeout(function() { e(g.definition) }, 0) : d(c, e)
                    },
                    zb: function(a) { delete k[a] },
                    ob: e
                };
                a.g.loaders = [];
                a.b("components", a.g);
                a.b("components.get", a.g.get);
                a.b("components.clearCachedDefinition", a.g.zb)
            })();
            (function() {
                function b(b, c, d, e) {
                    function k() { 0 === --v && e(h) }

                    var h = {}, v = 2, t = d.template;
                    d = d.viewModel;
                    t ? f(c, t, function(c) {
                        a.g.ob("loadTemplate", [b, c], function(a) {
                            h.template = a;
                            k()
                        })
                    }) : k();
                    d ? f(c, d, function(c) {
                            a.g.ob("loadViewModel", [b, c], function(a) {
                                h[l] = a;
                                k()
                            })
                        }) :
                        k()
                }

                function d(a, b, c) {
                    if ("function" === typeof b)c(function(a) { return new b(a) });
                    else if ("function" === typeof b[l])c(b[l]);
                    else if ("instance" in b) {
                        var e = b.instance;
                        c(function() { return e })
                    } else"viewModel" in b ? d(a, b.viewModel, c) : a("Unknown viewModel value: " + b)
                }

                function c(b) {
                    switch (a.a.v(b)) {
                    case "script":
                        return a.a.ca(b.text);
                    case "textarea":
                        return a.a.ca(b.value);
                    case "template":
                        if (e(b.content))return a.a.la(b.content.childNodes)
                    }
                    return a.a.la(b.childNodes)
                }

                function e(a) {
                    return y.DocumentFragment ? a instanceof
                        DocumentFragment : a && 11 === a.nodeType
                }

                function f(a, b, c) { "string" === typeof b.require ? O || y.require ? (O || y.require)([b.require], c) : a("Uses require, but no AMD loader is present") : c(b) }

                function k(a) { return function(b) { throw Error("Component '" + a + "': " + b); } }

                var h = {};
                a.g.register = function(b, c) {
                    if (!c)throw Error("Invalid configuration for " + b);
                    if (a.g.Xa(b))throw Error("Component " + b + " is already registered");
                    h[b] = c
                };
                a.g.Xa = function(a) { return a in h };
                a.g.Ec = function(b) {
                    delete h[b];
                    a.g.zb(b)
                };
                a.g.Ab = {
                    getConfig: function(a,
                        b) { b(h.hasOwnProperty(a) ? h[a] : null) },
                    loadComponent: function(a, c, d) {
                        var e = k(a);
                        f(e, c, function(c) { b(a, e, c, d) })
                    },
                    loadTemplate: function(b, d, f) {
                        b = k(b);
                        if ("string" === typeof d)f(a.a.ca(d));
                        else if (d instanceof Array)f(d);
                        else if (e(d))f(a.a.O(d.childNodes));
                        else if (d.element)
                            if (d = d.element, y.HTMLElement ? d instanceof HTMLElement : d && d.tagName && 1 === d.nodeType)f(c(d));
                            else if ("string" === typeof d) {
                                var l = w.getElementById(d);
                                l ? f(c(l)) : b("Cannot find element with ID " + d)
                            } else b("Unknown element type: " + d);
                        else
                            b("Unknown template value: " +
                                d)
                    },
                    loadViewModel: function(a, b, c) { d(k(a), b, c) }
                };
                var l = "createViewModel";
                a.b("components.register", a.g.register);
                a.b("components.isRegistered", a.g.Xa);
                a.b("components.unregister", a.g.Ec);
                a.b("components.defaultLoader", a.g.Ab);
                a.g.loaders.push(a.g.Ab);
                a.g.$b = h
            })();
            (function() {
                function b(b, e) {
                    var f = b.getAttribute("params");
                    if (f) {
                        var f = d.parseBindingsString(f, e, b, { valueAccessors: !0, bindingParams: !0 }),
                            f = a.a.pa(f, function(d) { return a.w(d, null, { q: b }) }),
                            k = a.a.pa(f, function(d) {
                                var e = d.B();
                                return d.$() ? a.w({
                                    read: function() { return a.a.c(d()) },
                                    write: a.Da(e) && function(a) { d()(a) },
                                    q: b
                                }) : e
                            });
                        k.hasOwnProperty("$raw") || (k.$raw = f);
                        return k
                    }
                    return{ $raw: {} }
                }

                a.g.getComponentNameForNode = function(b) {
                    b = a.a.v(b);
                    return a.g.Xa(b) && b
                };
                a.g.sb = function(c, d, f, k) {
                    if (1 === d.nodeType) {
                        var h = a.g.getComponentNameForNode(d);
                        if (h) {
                            c = c || {};
                            if (c.component)throw Error('Cannot use the "component" binding on a custom element matching a component');
                            var l = { name: h, params: b(d, f) };
                            c.component = k ? function() { return l } : l
                        }
                    }
                    return c
                };
                var d = new a.L;
                9 > a.a.M && (a.g.register = function(a) {
                    return function(b) {
                        w.createElement(b);
                        return a.apply(this, arguments)
                    }
                }(a.g.register), w.createDocumentFragment = function(b) {
                    return function() {
                        var d = b(), f = a.g.$b, k;
                        for (k in f)f.hasOwnProperty(k) && d.createElement(k);
                        return d
                    }
                }(w.createDocumentFragment))
            })();
            (function(b) {
                function d(b, c, d) {
                    c = c.template;
                    if (!c)throw Error("Component '" + b + "' has no template");
                    b = a.a.la(c);
                    a.e.T(d, b)
                }

                function c(a, b, c, d) {
                    var e = a.createViewModel;
                    return e ? e.call(a, d, { element: b, templateNodes: c }) : d
                }

                var e = 0;
                a.d.component = {
                    init: function(f, k, h, l, g) {
                        function m() {
                            var a = x &&
                                x.dispose;
                            "function" === typeof a && a.call(x);
                            q = null
                        }

                        var x, q, n = a.a.O(a.e.childNodes(f));
                        a.a.C.fa(f, m);
                        a.w(function() {
                            var l = a.a.c(k()), h, t;
                            "string" === typeof l ? h = l : (h = a.a.c(l.name), t = a.a.c(l.params));
                            if (!h)throw Error("No component name specified");
                            var p = q = ++e;
                            a.g.get(h, function(e) {
                                if (q === p) {
                                    m();
                                    if (!e)throw Error("Unknown component '" + h + "'");
                                    d(h, e, f);
                                    var l = c(e, f, n, t);
                                    e = g.createChildContext(l, b, function(a) {
                                        a.$component = l;
                                        a.$componentTemplateNodes = n
                                    });
                                    x = l;
                                    a.Ja(e, f)
                                }
                            })
                        }, null, { q: f });
                        return{ controlsDescendantBindings: !0 }
                    }
                };
                a.e.R.component = !0
            })();
            var P = { "class": "className", "for": "htmlFor" };
            a.d.attr = {
                update: function(b, d) {
                    var c = a.a.c(d()) || {};
                    a.a.A(c, function(c, d) {
                        d = a.a.c(d);
                        var k = !1 === d || null === d || d === p;
                        k && b.removeAttribute(c);
                        8 >= a.a.M && c in P ? (c = P[c], k ? b.removeAttribute(c) : b[c] = d) : k || b.setAttribute(c, d.toString());
                        "name" === c && a.a.Rb(b, k ? "" : d.toString())
                    })
                }
            };
            (function() {
                a.d.checked = {
                    after: ["value", "attr"],
                    init: function(b, d, c) {
                        function e() {
                            var e = b.checked, f = x ? k() : e;
                            if (!a.Z.Ca() && (!l || e)) {
                                var h = a.k.u(d);
                                g ? m !== f ? (e && (a.a.ga(h,
                                    f, !0), a.a.ga(h, m, !1)), m = f) : a.a.ga(h, f, e) : a.h.ra(h, c, "checked", f, !0)
                            }
                        }

                        function f() {
                            var c = a.a.c(d());
                            b.checked = g ? 0 <= a.a.m(c, k()) : h ? c : k() === c
                        }

                        var k = a.Nb(function() { return c.has("checkedValue") ? a.a.c(c.get("checkedValue")) : c.has("value") ? a.a.c(c.get("value")) : b.value }), h = "checkbox" == b.type, l = "radio" == b.type;
                        if (h || l) {
                            var g = h && a.a.c(d()) instanceof Array, m = g ? k() : p, x = l || g;
                            l && !b.name && a.d.uniqueName.init(b, function() { return!0 });
                            a.w(e, null, { q: b });
                            a.a.n(b, "click", e);
                            a.w(f, null, { q: b })
                        }
                    }
                };
                a.h.V.checked = !0;
                a.d.checkedValue =
                { update: function(b, d) { b.value = a.a.c(d()) } }
            })();
            a.d.css = {
                update: function(b, d) {
                    var c = a.a.c(d());
                    null !== c && "object" == typeof c ? a.a.A(c, function(c, d) {
                        d = a.a.c(d);
                        a.a.Ia(b, c, d)
                    }) : (c = String(c || ""), a.a.Ia(b, b.__ko__cssValue, !1), b.__ko__cssValue = c, a.a.Ia(b, c, !0))
                }
            };
            a.d.enable = {
                update: function(b, d) {
                    var c = a.a.c(d());
                    c && b.disabled ? b.removeAttribute("disabled") : c || b.disabled || (b.disabled = !0)
                }
            };
            a.d.disable = { update: function(b, d) { a.d.enable.update(b, function() { return!a.a.c(d()) }) } };
            a.d.event = {
                init: function(b, d, c,
                    e, f) {
                    var k = d() || {};
                    a.a.A(k, function(h) {
                        "string" == typeof h && a.a.n(b, h, function(b) {
                            var g, m = d()[h];
                            if (m) {
                                try {
                                    var k = a.a.O(arguments);
                                    e = f.$data;
                                    k.unshift(e);
                                    g = m.apply(e, k)
                                } finally {
                                    !0 !== g && (b.preventDefault ? b.preventDefault() : b.returnValue = !1)
                                }
                                !1 === c.get(h + "Bubble") && (b.cancelBubble = !0, b.stopPropagation && b.stopPropagation())
                            }
                        })
                    })
                }
            };
            a.d.foreach = {
                Ib: function(b) {
                    return function() {
                        var d = b(), c = a.a.cb(d);
                        if (!c || "number" == typeof c.length)return{ foreach: d, templateEngine: a.P.Va };
                        a.a.c(d);
                        return{
                            foreach: c.data,
                            as: c.as,
                            includeDestroyed: c.includeDestroyed,
                            afterAdd: c.afterAdd,
                            beforeRemove: c.beforeRemove,
                            afterRender: c.afterRender,
                            beforeMove: c.beforeMove,
                            afterMove: c.afterMove,
                            templateEngine: a.P.Va
                        }
                    }
                },
                init: function(b, d) { return a.d.template.init(b, a.d.foreach.Ib(d)) },
                update: function(b, d, c, e, f) { return a.d.template.update(b, a.d.foreach.Ib(d), c, e, f) }
            };
            a.h.ka.foreach = !1;
            a.e.R.foreach = !0;
            a.d.hasfocus = {
                init: function(b, d, c) {
                    function e(e) {
                        b.__ko_hasfocusUpdating = !0;
                        var f = b.ownerDocument;
                        if ("activeElement" in f) {
                            var g;
                            try {
                                g = f.activeElement
                            } catch (m) {
                                g =
                                    f.body
                            }
                            e = g === b
                        }
                        f = d();
                        a.h.ra(f, c, "hasfocus", e, !0);
                        b.__ko_hasfocusLastValue = e;
                        b.__ko_hasfocusUpdating = !1
                    }

                    var f = e.bind(null, !0), k = e.bind(null, !1);
                    a.a.n(b, "focus", f);
                    a.a.n(b, "focusin", f);
                    a.a.n(b, "blur", k);
                    a.a.n(b, "focusout", k)
                },
                update: function(b, d) {
                    var c = !!a.a.c(d());
                    b.__ko_hasfocusUpdating || b.__ko_hasfocusLastValue === c || (c ? b.focus() : b.blur(), a.k.u(a.a.qa, null, [b, c ? "focusin" : "focusout"]))
                }
            };
            a.h.V.hasfocus = !0;
            a.d.hasFocus = a.d.hasfocus;
            a.h.V.hasFocus = !0;
            a.d.html = {
                init: function() { return{ controlsDescendantBindings: !0 } },
                update: function(b, d) { a.a.gb(b, d()) }
            };
            K("if");
            K("ifnot", !1, !0);
            K("with", !0, !1, function(a, d) { return a.createChildContext(d) });
            var L = {};
            a.d.options = {
                init: function(b) {
                    if ("select" !== a.a.v(b))throw Error("options binding applies only to SELECT elements");
                    for (; 0 < b.length;)b.remove(0);
                    return{ controlsDescendantBindings: !0 }
                },
                update: function(b, d, c) {
                    function e() { return a.a.xa(b.options, function(a) { return a.selected }) }

                    function f(a, b, c) {
                        var d = typeof b;
                        return"function" == d ? b(a) : "string" == d ? a[b] : c
                    }

                    function k(d, e) {
                        if (r &&
                            m)a.i.Y(b, a.a.c(c.get("value")), !0);
                        else if (n.length) {
                            var g = 0 <= a.a.m(n, a.i.s(e[0]));
                            a.a.Sb(e[0], g);
                            r && !g && a.k.u(a.a.qa, null, [b, "change"])
                        }
                    }

                    var h = b.multiple, l = 0 != b.length && h ? b.scrollTop : null, g = a.a.c(d()), m = c.get("valueAllowUnset") && c.has("value"), x = c.get("optionsIncludeDestroyed");
                    d = {};
                    var q, n = [];
                    m || (h ? n = a.a.Ka(e(), a.i.s) : 0 <= b.selectedIndex && n.push(a.i.s(b.options[b.selectedIndex])));
                    g && ("undefined" == typeof g.length && (g = [g]), q = a.a.xa(g, function(b) { return x || b === p || null === b || !a.a.c(b._destroy) }), c.has("optionsCaption") &&
                    (g = a.a.c(c.get("optionsCaption")), null !== g && g !== p && q.unshift(L)));
                    var r = !1;
                    d.beforeRemove = function(a) { b.removeChild(a) };
                    g = k;
                    c.has("optionsAfterRender") && "function" == typeof c.get("optionsAfterRender") && (g = function(b, d) {
                        k(0, d);
                        a.k.u(c.get("optionsAfterRender"), null, [d[0], b !== L ? b : p])
                    });
                    a.a.fb(b, q, function(d, e, g) {
                        g.length && (n = !m && g[0].selected ? [a.i.s(g[0])] : [], r = !0);
                        e = b.ownerDocument.createElement("option");
                        d === L ? (a.a.Ha(e, c.get("optionsCaption")), a.i.Y(e, p)) : (g = f(d, c.get("optionsValue"), d), a.i.Y(e, a.a.c(g)),
                            d = f(d, c.get("optionsText"), g), a.a.Ha(e, d));
                        return[e]
                    }, d, g);
                    a.k.u(function() { m ? a.i.Y(b, a.a.c(c.get("value")), !0) : (h ? n.length && e().length < n.length : n.length && 0 <= b.selectedIndex ? a.i.s(b.options[b.selectedIndex]) !== n[0] : n.length || 0 <= b.selectedIndex) && a.a.qa(b, "change") });
                    a.a.kc(b);
                    l && 20 < Math.abs(l - b.scrollTop) && (b.scrollTop = l)
                }
            };
            a.d.options.ab = a.a.f.I();
            a.d.selectedOptions = {
                after: ["options", "foreach"],
                init: function(b, d, c) {
                    a.a.n(b, "change", function() {
                        var e = d(), f = [];
                        a.a.o(b.getElementsByTagName("option"),
                            function(b) { b.selected && f.push(a.i.s(b)) });
                        a.h.ra(e, c, "selectedOptions", f)
                    })
                },
                update: function(b, d) {
                    if ("select" != a.a.v(b))throw Error("values binding applies only to SELECT elements");
                    var c = a.a.c(d());
                    c && "number" == typeof c.length && a.a.o(b.getElementsByTagName("option"), function(b) {
                        var d = 0 <= a.a.m(c, a.i.s(b));
                        a.a.Sb(b, d)
                    })
                }
            };
            a.h.V.selectedOptions = !0;
            a.d.style = {
                update: function(b, d) {
                    var c = a.a.c(d() || {});
                    a.a.A(c, function(c, d) {
                        d = a.a.c(d);
                        if (null === d || d === p || !1 === d)d = "";
                        b.style[c] = d
                    })
                }
            };
            a.d.submit = {
                init: function(b,
                    d, c, e, f) {
                    if ("function" != typeof d())throw Error("The value for a submit binding must be a function");
                    a.a.n(b, "submit", function(a) {
                        var c, e = d();
                        try {
                            c = e.call(f.$data, b)
                        } finally {
                            !0 !== c && (a.preventDefault ? a.preventDefault() : a.returnValue = !1)
                        }
                    })
                }
            };
            a.d.text = { init: function() { return{ controlsDescendantBindings: !0 } }, update: function(b, d) { a.a.Ha(b, d()) } };
            a.e.R.text = !0;
            (function() {
                if (y && y.navigator)
                    var b = function(a) { if (a)return parseFloat(a[1]) },
                        d = y.opera && y.opera.version && parseInt(y.opera.version()),
                        c = y.navigator.userAgent,
                        e = b(c.match(/^(?:(?!chrome).)*version\/([^ ]*) safari/i)),
                        f = b(c.match(/Firefox\/([^ ]*)/));
                if (10 > a.a.M)
                    var k = a.a.f.I(), h = a.a.f.I(),
                        l = function(b) {
                            var c = this.activeElement;
                            (c = c && a.a.f.get(c, h)) && c(b)
                        },
                        g = function(b, c) {
                            var d = b.ownerDocument;
                            a.a.f.get(d, k) || (a.a.f.set(d, k, !0), a.a.n(d, "selectionchange", l));
                            a.a.f.set(b, h, c)
                        };
                a.d.textInput = {
                    init: function(b, c, l) {
                        function h(c, d) { a.a.n(b, c, d) }

                        function k() {
                            var d = a.a.c(c());
                            if (null === d || d === p)d = "";
                            w !== p && d === w ? setTimeout(k, 4) : b.value !== d && (u = d, b.value = d)
                        }

                        function v() {
                            A ||
                            (w = b.value, A = setTimeout(t, 4))
                        }

                        function t() {
                            clearTimeout(A);
                            w = A = p;
                            var d = b.value;
                            u !== d && (u = d, a.h.ra(c(), l, "textInput", d))
                        }

                        var u = b.value, A, w;
                        10 > a.a.M ? (h("propertychange", function(a) { "value" === a.propertyName && t() }), 8 == a.a.M && (h("keyup", t), h("keydown", t)), 8 <= a.a.M && (g(b, t), h("dragend", v))) : (h("input", t), 5 > e && "textarea" === a.a.v(b) ? (h("keydown", v), h("paste", v), h("cut", v)) : 11 > d ? h("keydown", v) : 4 > f && (h("DOMAutoComplete", t), h("dragdrop", t), h("drop", t)));
                        h("change", t);
                        a.w(k, null, { q: b })
                    }
                };
                a.h.V.textInput = !0;
                a.d.textinput =
                { preprocess: function(a, b, c) { c("textInput", a) } }
            })();
            a.d.uniqueName = {
                init: function(b, d) {
                    if (d()) {
                        var c = "ko_unique_" + ++a.d.uniqueName.fc;
                        a.a.Rb(b, c)
                    }
                }
            };
            a.d.uniqueName.fc = 0;
            a.d.value = {
                after: ["options", "foreach"],
                init: function(b, d, c) {
                    if ("input" != b.tagName.toLowerCase() || "checkbox" != b.type && "radio" != b.type) {
                        var e = ["change"], f = c.get("valueUpdate"), k = !1, h = null;
                        f && ("string" == typeof f && (f = [f]), a.a.ia(e, f), e = a.a.wb(e));
                        var l = function() {
                            h = null;
                            k = !1;
                            var e = d(), g = a.i.s(b);
                            a.h.ra(e, c, "value", g)
                        };
                        !a.a.M || "input" !=
                            b.tagName.toLowerCase() || "text" != b.type || "off" == b.autocomplete || b.form && "off" == b.form.autocomplete || -1 != a.a.m(e, "propertychange") || (a.a.n(b, "propertychange", function() { k = !0 }), a.a.n(b, "focus", function() { k = !1 }), a.a.n(b, "blur", function() { k && l() }));
                        a.a.o(e, function(c) {
                            var d = l;
                            a.a.Dc(c, "after") && (d = function() {
                                h = a.i.s(b);
                                setTimeout(l, 0)
                            }, c = c.substring(5));
                            a.a.n(b, c, d)
                        });
                        var g = function() {
                            var e = a.a.c(d()), f = a.i.s(b);
                            if (null !== h && e === h)setTimeout(g, 0);
                            else if (e !== f)
                                if ("select" === a.a.v(b)) {
                                    var l = c.get("valueAllowUnset"),
                                        f = function() { a.i.Y(b, e, l) };
                                    f();
                                    l || e === a.i.s(b) ? setTimeout(f, 0) : a.k.u(a.a.qa, null, [b, "change"])
                                } else a.i.Y(b, e)
                        };
                        a.w(g, null, { q: b })
                    } else a.va(b, { checkedValue: d })
                },
                update: function() {}
            };
            a.h.V.value = !0;
            a.d.visible = {
                update: function(b, d) {
                    var c = a.a.c(d()), e = "none" != b.style.display;
                    c && !e ? b.style.display = "" : !c && e && (b.style.display = "none")
                }
            };
            (function(b) {
                a.d[b] = {
                    init: function(d, c, e, f, k) {
                        return a.d.event.init.call(this, d, function() {
                            var a = {};
                            a[b] = c();
                            return a
                        }, e, f, k)
                    }
                }
            })("click");
            a.J = function() {};
            a.J.prototype.renderTemplateSource =
                function() { throw Error("Override renderTemplateSource"); };
            a.J.prototype.createJavaScriptEvaluatorBlock = function() { throw Error("Override createJavaScriptEvaluatorBlock"); };
            a.J.prototype.makeTemplateSource = function(b, d) {
                if ("string" == typeof b) {
                    d = d || w;
                    var c = d.getElementById(b);
                    if (!c)throw Error("Cannot find template with ID " + b);
                    return new a.t.l(c)
                }
                if (1 == b.nodeType || 8 == b.nodeType)return new a.t.ha(b);
                throw Error("Unknown template type: " + b);
            };
            a.J.prototype.renderTemplate = function(a, d, c, e) {
                a = this.makeTemplateSource(a,
                    e);
                return this.renderTemplateSource(a, d, c, e)
            };
            a.J.prototype.isTemplateRewritten = function(a, d) { return!1 === this.allowTemplateRewriting ? !0 : this.makeTemplateSource(a, d).data("isRewritten") };
            a.J.prototype.rewriteTemplate = function(a, d, c) {
                a = this.makeTemplateSource(a, c);
                d = d(a.text());
                a.text(d);
                a.data("isRewritten", !0)
            };
            a.b("templateEngine", a.J);
            a.kb = function() {
                function b(b, c, d, h) {
                    b = a.h.bb(b);
                    for (var l = a.h.ka, g = 0; g < b.length; g++) {
                        var m = b[g].key;
                        if (l.hasOwnProperty(m)) {
                            var x = l[m];
                            if ("function" === typeof x) {
                                if (m =
                                    x(b[g].value))throw Error(m);
                            } else if (!x)throw Error("This template engine does not support the '" + m + "' binding within its templates");
                        }
                    }
                    d = "ko.__tr_ambtns(function($context,$element){return(function(){return{ " + a.h.Ea(b, { valueAccessors: !0 }) + " } })()},'" + d.toLowerCase() + "')";
                    return h.createJavaScriptEvaluatorBlock(d) + c
                }

                var d = /(<([a-z]+\d*)(?:\s+(?!data-bind\s*=\s*)[a-z0-9\-]+(?:=(?:\"[^\"]*\"|\'[^\']*\'|[^>]*))?)*\s+)data-bind\s*=\s*(["'])([\s\S]*?)\3/gi, c = /\x3c!--\s*ko\b\s*([\s\S]*?)\s*--\x3e/g;
                return{
                    lc: function(b,
                        c, d) { c.isTemplateRewritten(b, d) || c.rewriteTemplate(b, function(b) { return a.kb.xc(b, c) }, d) },
                    xc: function(a, f) { return a.replace(d, function(a, c, d, e, m) { return b(m, c, d, f) }).replace(c, function(a, c) { return b(c, "\x3c!-- ko --\x3e", "#comment", f) }) },
                    dc: function(b, c) {
                        return a.H.$a(function(d, h) {
                            var l = d.nextSibling;
                            l && l.nodeName.toLowerCase() === c && a.va(l, b, h)
                        })
                    }
                }
            }();
            a.b("__tr_ambtns", a.kb.dc);
            (function() {
                a.t = {};
                a.t.l = function(a) { this.l = a };
                a.t.l.prototype.text = function() {
                    var b = a.a.v(this.l),
                        b = "script" === b ? "text" :
                            "textarea" === b ? "value" : "innerHTML";
                    if (0 == arguments.length)return this.l[b];
                    var d = arguments[0];
                    "innerHTML" === b ? a.a.gb(this.l, d) : this.l[b] = d
                };
                var b = a.a.f.I() + "_";
                a.t.l.prototype.data = function(c) {
                    if (1 === arguments.length)return a.a.f.get(this.l, b + c);
                    a.a.f.set(this.l, b + c, arguments[1])
                };
                var d = a.a.f.I();
                a.t.ha = function(a) { this.l = a };
                a.t.ha.prototype = new a.t.l;
                a.t.ha.prototype.text = function() {
                    if (0 == arguments.length) {
                        var b = a.a.f.get(this.l, d) || {};
                        b.lb === p && b.Na && (b.lb = b.Na.innerHTML);
                        return b.lb
                    }
                    a.a.f.set(this.l,
                        d, { lb: arguments[0] })
                };
                a.t.l.prototype.nodes = function() {
                    if (0 == arguments.length)return(a.a.f.get(this.l, d) || {}).Na;
                    a.a.f.set(this.l, d, { Na: arguments[0] })
                };
                a.b("templateSources", a.t);
                a.b("templateSources.domElement", a.t.l);
                a.b("templateSources.anonymousTemplate", a.t.ha)
            })();
            (function() {
                function b(b, c, d) {
                    var e;
                    for (c = a.e.nextSibling(c); b && (e = b) !== c;)b = a.e.nextSibling(e), d(e, b)
                }

                function d(c, d) {
                    if (c.length) {
                        var e = c[0], f = c[c.length - 1], h = e.parentNode, k = a.L.instance, r = k.preprocessNode;
                        if (r) {
                            b(e, f, function(a,
                                b) {
                                var c = a.previousSibling, d = r.call(k, a);
                                d && (a === e && (e = d[0] || b), a === f && (f = d[d.length - 1] || c))
                            });
                            c.length = 0;
                            if (!e)return;
                            e === f ? c.push(e) : (c.push(e, f), a.a.na(c, h))
                        }
                        b(e, f, function(b) { 1 !== b.nodeType && 8 !== b.nodeType || a.ub(d, b) });
                        b(e, f, function(b) { 1 !== b.nodeType && 8 !== b.nodeType || a.H.Xb(b, [d]) });
                        a.a.na(c, h)
                    }
                }

                function c(a) { return a.nodeType ? a : 0 < a.length ? a[0] : null }

                function e(b, e, f, h, q) {
                    q = q || {};
                    var n = (b && c(b) || f || {}).ownerDocument, r = q.templateEngine || k;
                    a.kb.lc(f, r, n);
                    f = r.renderTemplate(f, h, q, n);
                    if ("number" !=
                        typeof f.length || 0 < f.length && "number" != typeof f[0].nodeType)throw Error("Template engine must return an array of DOM nodes");
                    n = !1;
                    switch (e) {
                    case "replaceChildren":
                        a.e.T(b, f);
                        n = !0;
                        break;
                    case "replaceNode":
                        a.a.Qb(b, f);
                        n = !0;
                        break;
                    case "ignoreTargetNode":
                        break;
                    default:
                        throw Error("Unknown renderMode: " + e);
                    }
                    n && (d(f, h), q.afterRender && a.k.u(q.afterRender, null, [f, h.$data]));
                    return f
                }

                function f(b, c, d) { return a.F(b) ? b() : "function" === typeof b ? b(c, d) : b }

                var k;
                a.hb = function(b) {
                    if (b != p && !(b instanceof a.J))throw Error("templateEngine must inherit from ko.templateEngine");
                    k = b
                };
                a.eb = function(b, d, h, x, q) {
                    h = h || {};
                    if ((h.templateEngine || k) == p)throw Error("Set a template engine before calling renderTemplate");
                    q = q || "replaceChildren";
                    if (x) {
                        var n = c(x);
                        return a.j(function() {
                            var k = d && d instanceof a.N ? d : new a.N(a.a.c(d)), p = f(b, k.$data, k), k = e(x, q, p, k, h);
                            "replaceNode" == q && (x = k, n = c(x))
                        }, null, { Pa: function() { return!n || !a.a.Qa(n) }, q: n && "replaceNode" == q ? n.parentNode : n })
                    }
                    return a.H.$a(function(c) { a.eb(b, d, h, c, "replaceNode") })
                };
                a.Cc = function(b, c, h, k, q) {
                    function n(a, b) {
                        d(b, v);
                        h.afterRender &&
                            h.afterRender(b, a);
                        v = null
                    }

                    function r(a, c) {
                        v = q.createChildContext(a, h.as, function(a) { a.$index = c });
                        var d = f(b, a, v);
                        return e(null, "ignoreTargetNode", d, v, h)
                    }

                    var v;
                    return a.j(function() {
                        var b = a.a.c(c) || [];
                        "undefined" == typeof b.length && (b = [b]);
                        b = a.a.xa(b, function(b) { return h.includeDestroyed || b === p || null === b || !a.a.c(b._destroy) });
                        a.k.u(a.a.fb, null, [k, b, r, h, n])
                    }, null, { q: k })
                };
                var h = a.a.f.I();
                a.d.template = {
                    init: function(b, c) {
                        var d = a.a.c(c());
                        if ("string" == typeof d || d.name)a.e.ma(b);
                        else {
                            if ("nodes" in d) {
                                if (d =
                                    d.nodes || [], a.F(d))throw Error('The "nodes" option must be a plain, non-observable array.');
                            } else d = a.e.childNodes(b);
                            d = a.a.Jb(d);
                            (new a.t.ha(b)).nodes(d)
                        }
                        return{ controlsDescendantBindings: !0 }
                    },
                    update: function(b, c, d, e, f) {
                        var k = c(), r;
                        c = a.a.c(k);
                        d = !0;
                        e = null;
                        "string" == typeof c ? c = {} : (k = c.name, "if" in c && (d = a.a.c(c["if"])), d && "ifnot" in c && (d = !a.a.c(c.ifnot)), r = a.a.c(c.data));
                        "foreach" in c ? e = a.Cc(k || b, d && c.foreach || [], c, b, f) : d ? (f = "data" in c ? f.createChildContext(r, c.as) : f, e = a.eb(k || b, f, c, b)) : a.e.ma(b);
                        f =
                            e;
                        (r = a.a.f.get(b, h)) && "function" == typeof r.p && r.p();
                        a.a.f.set(b, h, f && f.$() ? f : p)
                    }
                };
                a.h.ka.template = function(b) {
                    b = a.h.bb(b);
                    return 1 == b.length && b[0].unknown || a.h.vc(b, "name") ? null : "This template engine does not support anonymous templates nested within its templates"
                };
                a.e.R.template = !0
            })();
            a.b("setTemplateEngine", a.hb);
            a.b("renderTemplate", a.eb);
            a.a.Cb = function(a, d, c) {
                if (a.length && d.length) {
                    var e, f, k, h, l;
                    for (e = f = 0; (!c || e < c) && (h = a[f]); ++f) {
                        for (k = 0; l = d[k]; ++k)
                            if (h.value === l.value) {
                                h.moved = l.index;
                                l.moved =
                                    h.index;
                                d.splice(k, 1);
                                e = k = 0;
                                break
                            }
                        e += k
                    }
                }
            };
            a.a.Ma = function() {
                function b(b, c, e, f, k) {
                    var h = Math.min, l = Math.max, g = [], m, p = b.length, q, n = c.length, r = n - p || 1, v = p + n + 1, t, u, w;
                    for (m = 0; m <= p; m++)for (u = t, g.push(t = []), w = h(n, m + r), q = l(0, m - 1); q <= w; q++)t[q] = q ? m ? b[m - 1] === c[q - 1] ? u[q - 1] : h(u[q] || v, t[q - 1] || v) + 1 : q + 1 : m + 1;
                    h = [];
                    l = [];
                    r = [];
                    m = p;
                    for (q = n; m || q;)
                        n = g[m][q] - 1, q && n === g[m][q - 1] ? l.push(h[h.length] = { status: e, value: c[--q], index: q }) : m && n === g[m - 1][q] ? r.push(h[h.length] = { status: f, value: b[--m], index: m }) : (--q, --m, k.sparse || h.push({
                            status: "retained",
                            value: c[q]
                        }));
                    a.a.Cb(l, r, 10 * p);
                    return h.reverse()
                }

                return function(a, c, e) {
                    e = "boolean" === typeof e ? { dontLimitMoves: e } : e || {};
                    a = a || [];
                    c = c || [];
                    return a.length <= c.length ? b(a, c, "added", "deleted", e) : b(c, a, "deleted", "added", e)
                }
            }();
            a.b("utils.compareArrays", a.a.Ma);
            (function() {
                function b(b, d, f, k, h) {
                    var l = [],
                        g = a.j(function() {
                            var g = d(f, h, a.a.na(l, b)) || [];
                            0 < l.length && (a.a.Qb(l, g), k && a.k.u(k, null, [f, g, h]));
                            l.length = 0;
                            a.a.ia(l, g)
                        }, null, { q: b, Pa: function() { return!a.a.tb(l) } });
                    return{ aa: l, j: g.$() ? g : p }
                }

                var d = a.a.f.I();
                a.a.fb = function(c, e, f, k, h) {
                    function l(b, d) {
                        s = u[d];
                        t !== d && (z[b] = s);
                        s.Ua(t++);
                        a.a.na(s.aa, c);
                        r.push(s);
                        y.push(s)
                    }

                    function g(b, c) { if (b)for (var d = 0, e = c.length; d < e; d++)c[d] && a.a.o(c[d].aa, function(a) { b(a, d, c[d].wa) }) }

                    e = e || [];
                    k = k || {};
                    var m = a.a.f.get(c, d) === p, u = a.a.f.get(c, d) || [], q = a.a.Ka(u, function(a) { return a.wa }), n = a.a.Ma(q, e, k.dontLimitMoves), r = [], v = 0, t = 0, w = [], y = [];
                    e = [];
                    for (var z = [], q = [], s, C = 0, D, E; D = n[C]; C++)
                        switch (E = D.moved, D.status) {
                        case "deleted":
                            E === p && (s = u[v], s.j && s.j.p(), w.push.apply(w, a.a.na(s.aa,
                                c)), k.beforeRemove && (e[C] = s, y.push(s)));
                            v++;
                            break;
                        case "retained":
                            l(C, v++);
                            break;
                        case "added":
                            E !== p ? l(C, E) : (s = { wa: D.value, Ua: a.r(t++) }, r.push(s), y.push(s), m || (q[C] = s))
                        }
                    g(k.beforeMove, z);
                    a.a.o(w, k.beforeRemove ? a.S : a.removeNode);
                    for (var C = 0, m = a.e.firstChild(c), H; s = y[C]; C++) {
                        s.aa || a.a.extend(s, b(c, f, s.wa, h, s.Ua));
                        for (v = 0; n = s.aa[v]; m = n.nextSibling, H = n, v++)n !== m && a.e.Fb(c, n, H);
                        !s.rc && h && (h(s.wa, s.aa, s.Ua), s.rc = !0)
                    }
                    g(k.beforeRemove, e);
                    g(k.afterMove, z);
                    g(k.afterAdd, q);
                    a.a.f.set(c, d, r)
                }
            })();
            a.b("utils.setDomNodeChildrenFromArrayMapping",
                a.a.fb);
            a.P = function() { this.allowTemplateRewriting = !1 };
            a.P.prototype = new a.J;
            a.P.prototype.renderTemplateSource = function(b, d, c, e) {
                if (d = (9 > a.a.M ? 0 : b.nodes) ? b.nodes() : null)return a.a.O(d.cloneNode(!0).childNodes);
                b = b.text();
                return a.a.ca(b, e)
            };
            a.P.Va = new a.P;
            a.hb(a.P.Va);
            a.b("nativeTemplateEngine", a.P);
            (function() {
                a.Ya = function() {
                    var a = this.uc = function() {
                        if (!u || !u.tmpl)return 0;
                        try {
                            if (0 <= u.tmpl.tag.tmpl.open.toString().indexOf("__"))return 2
                        } catch (a) {
                        }
                        return 1
                    }();
                    this.renderTemplateSource = function(b,
                        e, f, k) {
                        k = k || w;
                        f = f || {};
                        if (2 > a)throw Error("Your version of jQuery.tmpl is too old. Please upgrade to jQuery.tmpl 1.0.0pre or later.");
                        var h = b.data("precompiled");
                        h || (h = b.text() || "", h = u.template(null, "{{ko_with $item.koBindingContext}}" + h + "{{/ko_with}}"), b.data("precompiled", h));
                        b = [e.$data];
                        e = u.extend({ koBindingContext: e }, f.templateOptions);
                        e = u.tmpl(h, b, e);
                        e.appendTo(k.createElement("div"));
                        u.fragments = {};
                        return e
                    };
                    this.createJavaScriptEvaluatorBlock = function(a) {
                        return"{{ko_code ((function() { return " +
                            a + " })()) }}"
                    };
                    this.addTemplate = function(a, b) { w.write("<script type='text/html' id='" + a + "'>" + b + "\x3c/script>") };
                    0 < a && (u.tmpl.tag.ko_code = { open: "__.push($1 || '');" }, u.tmpl.tag.ko_with = { open: "with($1) {", close: "} " })
                };
                a.Ya.prototype = new a.J;
                var b = new a.Ya;
                0 < b.uc && a.hb(b);
                a.b("jqueryTmplTemplateEngine", a.Ya)
            })()
        })
    })();
})();