﻿using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using log4net;
using Snappet.App_Start;

namespace Snappet
{
    /// <summary>
    /// 
    /// </summary>
    public class MvcApplication : System.Web.HttpApplication
    {
        #region Fields

        private static readonly ILog _log =
            LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #endregion

        #region Properties

        /// <summary>
        /// 
        /// </summary>
        public static ILog Logger
        {
            get { return _log; }
        }

        #endregion

        #region Methods

        protected void Application_Start()
        {
            log4net.Config.XmlConfigurator.Configure();

            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            RepositoryConfig.RegisterRepository();
        }

        #endregion
    }
}