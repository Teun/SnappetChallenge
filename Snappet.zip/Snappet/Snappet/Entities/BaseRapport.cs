﻿namespace Snappet.Entities
{
    /// <summary>
    /// 
    /// </summary>
    public class BaseRapport
    {
        /// <summary>
        /// 
        /// </summary>
        public string[] X { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int[] Y { get; set; }
    }
}