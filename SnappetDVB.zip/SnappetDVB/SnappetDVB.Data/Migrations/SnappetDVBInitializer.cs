﻿using Newtonsoft.Json;
using SnappetDVB.Model.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace SnappetDVB.Data
{
    public class SnappetDVBInitializer : CreateDatabaseIfNotExists<SnappetDVBContext>
    {
        protected override void Seed(SnappetDVBContext context)
        {
            ImportJSONInSQL(context);
        }

        private void ImportJSONInSQL(SnappetDVBContext context)
        {

            List<SubmittedAnswer> Answers = new List<SubmittedAnswer> { };

            string jsonfile = (new System.Uri(Assembly.GetExecutingAssembly().CodeBase)).AbsolutePath.Replace("SnappetDVB.Data.DLL", "RawData/raw.json");

            using (StreamReader r = new StreamReader(jsonfile))
            {
                string json = r.ReadToEnd();

                // Replace "NULL" to deserialize "Diffciculty" paramter correctly.
                json = json.Replace(@"""Difficulty"":""NULL""", @"""Difficulty"":""""");

                Answers = JsonConvert.DeserializeObject<List<SubmittedAnswer>>(json);
            }

            context.Configuration.AutoDetectChangesEnabled = false;

            //Answers = Answers.Take(10000).ToList();

            int counter = 0;
            foreach (SubmittedAnswer ans in Answers)
            {
                counter += 1;
                context.SubmittedAnswers.Add(ans);

                if (counter % 50 == 0)
                {
                    context.SaveChanges();
                }
            }

            context.SaveChanges();

            base.Seed(context);
        }

    }
}
