﻿using SnappetDVB.Model.Entities;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace SnappetDVB.Data
{
    public class SnappetDVBContext : DbContext
    {
        public SnappetDVBContext() : base("DSN")
        {
            Database.SetInitializer(new SnappetDVBInitializer());
        }

        public DbSet<SubmittedAnswer> SubmittedAnswers { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

        //https://www.codeproject.com/Articles/753510/SocialClub-A-Sample-application-using-Csharp-NET-E
        //https://www.asp.net/mvc/overview/getting-started/getting-started-with-ef-using-mvc/creating-an-entity-framework-data-model-for-an-asp-net-mvc-application
    }
}