﻿using SnappetDVB.Model.Entities;
using SnappetDVB.Web.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnappetDVB.Data.Repository
{
    public class SnappetRepository : IDisposable
    {
        private SnappetDVBContext _snappetDVBContext;

        public SnappetRepository()
        {
            _snappetDVBContext = new SnappetDVBContext();
        }
        
        public UserProgressViewModel GetProgressData ()
        {

            List<SubmittedAnswer> result = (from ans in _snappetDVBContext.SubmittedAnswers
                                            where ans.SubmitDateTime < new DateTime(2015, 03, 24, 11, 30, 00)
                                            where ans.SubmitDateTime > new DateTime(2015, 03, 24, 0, 0, 0)
                                            select ans).ToList();

            List<KeyValuePair<string, int>> MaxValues = (from sa in result
                                                         where sa.SubmitDateTime < new DateTime(2015, 03, 24, 11, 30, 00)
                                                         where sa.SubmitDateTime > new DateTime(2015, 03, 24, 0, 0, 0)
                                                         group sa by new { sa.UserId, sa.LearningObjective } into gsa
                                                         select new
                                                         {
                                                             UserId = gsa.Key.UserId,
                                                             LearningObjective = gsa.Key.LearningObjective,
                                                             TotalAnswer = gsa.Count()
                                                         }).GroupBy(l => l.LearningObjective)
                                                .Select(group => new
                                                {
                                                    LearningObjective = group.Key,
                                                    MaxAnswered = group.Max(x => x.TotalAnswer)
                                                }).Select(o => new KeyValuePair<string, int>(o.LearningObjective, o.MaxAnswered)).ToList();

            UserProgressViewModel progress = new UserProgressViewModel();
            progress.SubmittedAnswers = result;
            progress.LearningObjectiveMaxValues = MaxValues;

            return progress;
        }

        public UserProgressViewModel GetProgressDataForUser(int? id) {

            UserProgressViewModel progress = GetProgressData();

            List<SubmittedAnswer> userresult = (from ans in progress.SubmittedAnswers
                                                where ans.UserId == (int)id
                                                select ans).ToList();

            progress.SubmittedAnswers = userresult;

            return progress;
        }

        private bool _disposed;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _snappetDVBContext.Dispose();
                }
            }
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
