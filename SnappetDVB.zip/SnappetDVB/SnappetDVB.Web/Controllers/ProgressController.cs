﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SnappetDVB.Data;
using SnappetDVB.Model.Entities;
using SnappetDVB.Web.ViewModels;
using SnappetDVB.Data.Repository;

namespace SnappetDVB.Web.Controllers
{
    public class ProgressController : Controller
    {

        private SnappetRepository _repository;

        public ProgressController()
        {
            _repository = new SnappetRepository();
        }       

        public ActionResult Index()
        {           
            UserProgressViewModel progress = _repository.GetProgressData();

            return View(progress);
        }
        
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
                        
            UserProgressViewModel progress = _repository.GetProgressDataForUser(id);

            if (progress.SubmittedAnswers.Count == 0)
            {
                return HttpNotFound();
            }

            return View(progress);
        }
    }
}
