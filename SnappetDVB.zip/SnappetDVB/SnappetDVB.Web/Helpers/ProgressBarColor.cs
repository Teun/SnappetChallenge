﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SnappetDVB.Web.Helpers
{
    public class ProgressBarColor
    {

        public static string GetCSS(int progress) {

            string result = "";

            if (progress > 80)
            {
                result = "progress-bar-success";
            }
            else if (progress > 65)
            {
                result = "progress-bar-info";
            }
            else if (progress > 50)
            {
                result = "progress-bar-warning";
            }
            else {
                result = "progress-bar-danger";
            }
                        
            return result;
        }
        
    }
}