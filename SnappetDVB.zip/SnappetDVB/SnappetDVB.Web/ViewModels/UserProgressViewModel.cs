﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SnappetDVB.Model.Entities;

namespace SnappetDVB.Web.ViewModels
{
    public class UserProgressViewModel
    {
        public UserProgressViewModel()
        {
            SubmittedAnswers = new List<SubmittedAnswer>();
            LearningObjectiveMaxValues = new List<KeyValuePair<string, int>>();
        }

        public List<SubmittedAnswer> SubmittedAnswers { get; set; }
        
        public List<KeyValuePair<string, int>> LearningObjectiveMaxValues {get; set; }
    }
}