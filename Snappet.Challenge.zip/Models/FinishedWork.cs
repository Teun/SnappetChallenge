﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Snappet.Challenge.DAL;

namespace Snappet.Challenge.Models
{
	public class FinishedWork
	{
		[Display(Name = "Onderwerp : ")]
		public string SubjectId { get; set; }

		public SelectList Subjects { get; set; }

		public List<User> UserList { get; set; }

		/// <summary>
		/// Get the subjects
		/// </summary>
		/// <param name="dbContext"></param>
		/// <returns></returns>
		public SelectList GetSubjects(SnappetDBEntities dbContext)
		{
			ListItemCollection lic = new ListItemCollection();

			var subjects = dbContext.SubmittedAnswers.Select(x => x.Subject).Distinct();

			foreach (var s in subjects)
			{
				ListItem li = new ListItem();
				li.Text = s;
				li.Value = s;
				lic.Add(li);
			}

			return new SelectList(lic, "Value", "Text");
		}

		/// <summary>
		/// Get the users
		/// </summary>
		/// <param name="dbContext"></param>
		/// <returns></returns>
		private List<User> GetUsers(SnappetDBEntities dbContext)
		{
			return dbContext.Users.OrderBy(x => x.Name).ToList();
		}

		/// <summary>
		/// Get the base data
		/// </summary>
		/// <param name="dbContext"></param>
		internal void GetBaseData(SnappetDBEntities dbContext)
		{
			Subjects = GetSubjects(dbContext);
			UserList = GetUsers(dbContext);
		}

		/// <summary>
		/// Get the results
		/// </summary>
		/// <param name="data"></param>
		internal void GetResults(IQueryable<SubmittedAnswer> data)
		{
			try
			{
				// Set now date
				DateTime now = new DateTime(2015, 03, 24, 12, 30, 0);

				// Determine timezone
				TimeZone localZone = TimeZone.CurrentTimeZone;

				// Set from and till time for today's results
				DateTime from = localZone.ToUniversalTime(now).Date;
				DateTime till = localZone.ToUniversalTime(now);

				// Set from and till time for results previous week
				DateTime fromPr = from.AddDays(-(int)from.DayOfWeek - 6); // Mondag
				DateTime tillPr = fromPr.AddDays(5); // Friday

				foreach (var u in UserList)
				{
					// Get submitted answers for this student today.
					var userData = data.Where(x => x.UserId == u.Id && x.SubmitDateTime >= from && x.SubmitDateTime <= till);
					IEnumerable<string> learningObjectives = userData.Select(x => x.LearningObjective).Distinct();

					u.LearningObjectives = new List<LearningObjective>();

					foreach (var l in learningObjectives)
					{
						LearningObjective lo = new LearningObjective();
						lo.Name = l;
						lo.UserId = u.Id;
						lo.Subject = userData.Where(x => x.LearningObjective == l).Select(x => x.Subject).First();
						lo.Domain = userData.Where(x => x.LearningObjective == l).Select(x => x.Domain).First();

						// Calculate average progress for today. Omit when Progress == 0.
						List<int> progressListToday = userData.Where(
							x => x.LearningObjective == lo.Name 
								&& x.Progress != 0).Select(x => x.Progress).ToList();

						lo.AvgProgress = GetProgress(progressListToday);

						// Calculate average progress previous week. Omit when Progress == 0.
						List<int> progressListPreviousWeek = data.Where(
							x => x.UserId == u.Id
								&& DbFunctions.TruncateTime(x.SubmitDateTime) >= DbFunctions.TruncateTime(fromPr)
								&& DbFunctions.TruncateTime(x.SubmitDateTime) <= DbFunctions.TruncateTime(tillPr)
								&& x.LearningObjective == lo.Name
								&& x.Progress != 0).Select(x => x.Progress).ToList();

						lo.AvgProgressPreviousWeek = GetProgress(progressListPreviousWeek);

						u.LearningObjectives.Add(lo);
					}

					// Sort
					u.LearningObjectives = u.LearningObjectives.OrderBy(x => x.Domain).ThenBy(x => x.Name).ToList();
				}
			}
			catch (Exception)
			{
				// Handle the error
			}
		}

		/// <summary>
		/// Get the progress
		/// </summary>
		/// <param name="progressList"></param>
		/// <returns></returns>
		private static string GetProgress(List<int> progressList)
		{
			string avgProgressStr = @"<i class='fa fa-circle lightgrey' title='Onbekend'></i> n.b.";
			
			try
			{
				if (progressList == null)
					return avgProgressStr;

				if (progressList.Count() > 0)
				{
					double avgProgress = progressList.Average();

					if (avgProgress == 0)
						avgProgressStr = @"<i class='fa fa-circle lightgrey' title='Neutraal'></i> " + String.Format("{0:N2}", avgProgress);
					else if (avgProgress < 0)
						avgProgressStr = @"<i class='fa fa-minus red' title='Min'></i> " + String.Format("{0:N2}", Math.Abs(avgProgress));
					else if (avgProgress > 0)
						avgProgressStr = @"<i class='fa fa-plus green' title='Plus'></i> " + String.Format("{0:N2}", avgProgress);
				}
			}
			catch (Exception)
			{
				// Handle the error
			}
			return avgProgressStr;
		}
	}
}