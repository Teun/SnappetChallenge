﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snappet.Challenge.DAL
{
	public partial class User
	{
		public List<LearningObjective> LearningObjectives { get; set; }
	}
}