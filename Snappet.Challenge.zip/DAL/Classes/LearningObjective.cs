﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snappet.Challenge.DAL
{
	public class LearningObjective
	{
		public string Name { get; set; }
		public int UserId { get; set; }
		public string Subject { get; set; }
		public string Domain { get; set; }
		public string AvgProgress { get; set; }
		public string AvgProgressPreviousWeek { get; set; }
	}
}