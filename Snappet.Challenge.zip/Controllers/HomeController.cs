﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Snappet.Challenge.DAL;
using Snappet.Challenge.Models;

namespace Snappet.Challenge.Controllers
{
	public class HomeController : Controller
	{
		public SnappetDBEntities dbContext { get; set; }

		private DateTime _now;

		public DateTime Now
		{
			// Set Date to simulate todays date and time
			get { return new DateTime(2015, 03, 24, 12, 30, 0); }
			set { _now = value; }
		}

		/// <summary>
		/// Index
		/// </summary>
		/// <returns></returns>
		public ActionResult Index()
		{
			ViewBag.CurrentDateTime = Now.ToShortDateString() + " " + Now.ToShortTimeString();

			dbContext = new SnappetDBEntities();

			// Fill model
			FinishedWork model = new FinishedWork();
			model.GetBaseData(dbContext);

			return View(model);
		}

		/// <summary>
		/// Index post
		/// </summary>
		/// <param name="model"></param>
		/// <returns></returns>
		[HttpPost]
		public ActionResult Index(FinishedWork model)
		{
			ViewBag.CurrentDateTime = Now.ToShortDateString() + " " + Now.ToShortTimeString();

			dbContext = new SnappetDBEntities();

			model.GetBaseData(dbContext);
			
			// Get results
			var data = dbContext.SubmittedAnswers.Where(x => x.Subject == model.SubjectId);
			model.GetResults(data);

			return View(model);
		}
	}
}