﻿function Answer(data) {
    var self = this;
    self.SubmittedAnswerId = data.SubmittedAnswerId;
    self.SubmittedDateTime = data.SubmittedDateTime;
    self.Correct = data.Correct;
    self.Progress = data.Progress;
    self.UserId = data.UserId;
    self.ExerciseId = data.ExerciseId;
    self.Difficulty = data.Difficulty;
    self.Subject = data.Subject;
    self.Domain = data.Domain;
    self.LearningObjective = data.LearningObjective;
    self.IsCorrect = ko.computed(function () {
        return data.Correct ? "Yes" : "No";
    }, this);
}

function SubmittedAnswersViewModel() {
    var self = this;
    self.answers = ko.observableArray();
    self.selectedSortOption = ko.observable();

    self.sortOptions = [
        { cod: 1, text: "Answer" },
        { cod: 2, text: "Submitted Date" },
        { cod: 3, text: "Correction" },
        { cod: 4, text: "Progress" },
        { cod: 5, text: "User" },
        { cod: 6, text: "Exercise" },
        { cod: 7, text: "Difficulty" },
        { cod: 8, text: "Subject" },
        { cod: 9, text: "Domain" },
        { cod: 10, text: "Learning Objective" }
    ];

    self.applyFilters = function () {
        var selectSortOptionCod = this.selectedSortOption().cod;
        var sort = { "PgSize": 20, "PgNumber": 1, "IsDescendant": true, "SortBy": selectSortOptionCod };
        GetSubmittedAnswersAll(sort);
    }

    $(document).ready(function () {
        var sort = { "PgSize": 20, "PgNumber": 1, "IsDescendant": true, "SortBy": 1 };
        var userId = $("#hiddenStudentId").val();
        GetSubmittedAnswersAll(sort, userId);
    });

    function GetSubmittedAnswersAll(sort, userId) {
        $.ajax({
            url: "/Answer/AnswersJson/",
            type: "POST",
            dataType: "json",
            data: { sort: JSON.stringify(sort), userId: userId },
            success: function (data) {
                self.answers.removeAll();
                $.each(data, function (key, value) {
                    self.answers.push(new Answer(value));
                });
            },
            error: function (xhr) { alert(xhr.status) }
        });
    }
}

ko.applyBindings(SubmittedAnswersViewModel, document.getElementById("submittedAnswersViewModel"));