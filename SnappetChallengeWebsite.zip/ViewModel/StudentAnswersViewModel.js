﻿function StudentAnswers(data) {
    var self = this;
    self.StudentId = data.StudentId;
    self.TotalAnswers = data.TotalAnswers;
    self.CorrectAnswers = data.CorrectAnswers;
    self.IncorrectAnswers = data.IncorrectAnswers;
}

function StudentAnswersViewModel() {
    var self = this;
    self.studentAnswers = ko.observableArray();

    $(document).ready(function () {
        GetStudentsSubmittedAnswers();
    });

    self.getAnswersAll = function (data) {
        var sort = { "PgSize": 100, "PgNumber": 1, "IsDescendant": true, "SortBy": 1 };
        GetSubmittedAnswersAll(data.StudentId);

    }

    function GetStudentsSubmittedAnswers() {
        $.ajax({
            url: "/Student/StudentAnswersJson/",
            type: "POST",
            dataType: "json",
            success: function (data) {
                self.studentAnswers.removeAll();
                $.each(data, function (key, value) {
                    self.studentAnswers.push(new StudentAnswers(value));
                });
            },
            error: function (xhr) { alert(xhr.status) }
        });
    }
}

ko.applyBindings(StudentAnswersViewModel, document.getElementById("studentAnswersViewModel"));